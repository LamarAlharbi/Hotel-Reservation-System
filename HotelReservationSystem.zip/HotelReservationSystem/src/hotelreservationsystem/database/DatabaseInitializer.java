package hotelreservationsystem.database;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseInitializer {

    public static void initializeSchema() {
        Connection conn = null;
        Statement stmt = null;

        try {
            conn = DatabaseConnection.getInstance().getConnection();
            stmt = conn.createStatement();

            System.out.println("Initializing database schema...");

            dropTablesAndSequences(stmt);
            createSequences(stmt);
            createTables(stmt);

            System.out.println("Database schema initialized successfully!");

        } catch (SQLException e) {
            System.err.println("Error initializing database schema!");
            e.printStackTrace();
        } finally {
            try {
                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    private static void dropTablesAndSequences(Statement stmt) throws SQLException {
        try {
            stmt.execute("DROP TABLE RESERVATION_SERVICES CASCADE CONSTRAINTS");
            System.out.println("Dropped RESERVATION_SERVICES table");
        } catch (SQLException e) {
            /* Table doesn't exist */ }

        try {
            stmt.execute("DROP TABLE RESERVATIONS CASCADE CONSTRAINTS");
            System.out.println("Dropped RESERVATIONS table");
        } catch (SQLException e) {
            /* Table doesn't exist */ }

        try {
            stmt.execute("DROP TABLE SERVICES CASCADE CONSTRAINTS");
            System.out.println("Dropped SERVICES table");
        } catch (SQLException e) {
            /* Table doesn't exist */ }

        try {
            stmt.execute("DROP TABLE ROOMS CASCADE CONSTRAINTS");
            System.out.println("Dropped ROOMS table");
        } catch (SQLException e) {
            /* Table doesn't exist */ }

        try {
            stmt.execute("DROP TABLE USERS CASCADE CONSTRAINTS");
            System.out.println("Dropped USERS table");
        } catch (SQLException e) {
            /* Table doesn't exist */ }
        String[] sequences = {"USER_SEQ", "ROOM_SEQ", "RESERVATION_SEQ", "SERVICE_SEQ", "RES_SERVICE_SEQ"};
        for (String seq : sequences) {
            try {
                stmt.execute("DROP SEQUENCE " + seq);
                System.out.println("Dropped sequence " + seq);
            } catch (SQLException e) {
            }
        }
    }

    private static void createSequences(Statement stmt) throws SQLException {
        stmt.execute("CREATE SEQUENCE USER_SEQ START WITH 1 INCREMENT BY 1");
        stmt.execute("CREATE SEQUENCE ROOM_SEQ START WITH 1 INCREMENT BY 1");
        stmt.execute("CREATE SEQUENCE RESERVATION_SEQ START WITH 1 INCREMENT BY 1");
        stmt.execute("CREATE SEQUENCE SERVICE_SEQ START WITH 1 INCREMENT BY 1");
        stmt.execute("CREATE SEQUENCE RES_SERVICE_SEQ START WITH 1 INCREMENT BY 1");
        System.out.println("Created all sequences");
    }

    private static void createTables(Statement stmt) throws SQLException {
        // Create USERS table
        String createUsers = "CREATE TABLE USERS ("
                + "USER_ID NUMBER PRIMARY KEY, "
                + "USERNAME VARCHAR2(50) UNIQUE NOT NULL, "
                + "PASSWORD VARCHAR2(100) NOT NULL, "
                + "FULL_NAME VARCHAR2(100) NOT NULL, "
                + "EMAIL VARCHAR2(100) UNIQUE NOT NULL, "
                + "PHONE VARCHAR2(20), "
                + "ADDRESS VARCHAR2(200), "
                + "ROLE VARCHAR2(20) NOT NULL CHECK (ROLE IN ('GUEST', 'RECEPTIONIST', 'ADMINISTRATOR')), "
                + "CREATED_DATE DATE DEFAULT SYSDATE)";
        stmt.execute(createUsers);
        System.out.println("Created USERS table");
        String createRooms = "CREATE TABLE ROOMS ("
                + "ROOM_ID NUMBER PRIMARY KEY, "
                + "ROOM_NUMBER VARCHAR2(10) UNIQUE NOT NULL, "
                + "ROOM_TYPE VARCHAR2(50) NOT NULL, "
                + "PRICE_PER_NIGHT NUMBER(10,2) NOT NULL, "
                + "CAPACITY NUMBER NOT NULL, "
                + "AMENITIES VARCHAR2(500), "
                + "STATUS VARCHAR2(20) DEFAULT 'AVAILABLE' CHECK (STATUS IN ('AVAILABLE', 'OCCUPIED', 'MAINTENANCE')), "
                + "DESCRIPTION VARCHAR2(1000))";
        stmt.execute(createRooms);
        System.out.println("Created ROOMS table");
        String createReservations = "CREATE TABLE RESERVATIONS ("
                + "RESERVATION_ID NUMBER PRIMARY KEY, "
                + "GUEST_ID NUMBER NOT NULL, "
                + "ROOM_ID NUMBER NOT NULL, "
                + "CHECK_IN_DATE DATE NOT NULL, "
                + "CHECK_OUT_DATE DATE NOT NULL, "
                + "RESERVATION_DATE DATE DEFAULT SYSDATE, "
                + "STATUS VARCHAR2(20) DEFAULT 'PENDING' CHECK (STATUS IN ('PENDING', 'CONFIRMED', 'CHECKED_IN', 'CHECKED_OUT', 'CANCELLED')), "
                + "TOTAL_PRICE NUMBER(10,2) NOT NULL, "
                + "NOTES VARCHAR2(500), "
                + "CONSTRAINT FK_GUEST FOREIGN KEY (GUEST_ID) REFERENCES USERS(USER_ID), "
                + "CONSTRAINT FK_ROOM FOREIGN KEY (ROOM_ID) REFERENCES ROOMS(ROOM_ID))";
        stmt.execute(createReservations);
        System.out.println("Created RESERVATIONS table");
        String createServices = "CREATE TABLE SERVICES ("
                + "SERVICE_ID NUMBER PRIMARY KEY, "
                + "SERVICE_NAME VARCHAR2(100) NOT NULL, "
                + "DESCRIPTION VARCHAR2(500), "
                + "PRICE NUMBER(10,2) NOT NULL)";
        stmt.execute(createServices);
        System.out.println("Created SERVICES table");
        String createReservationServices = "CREATE TABLE RESERVATION_SERVICES ("
                + "RESERVATION_SERVICE_ID NUMBER PRIMARY KEY, "
                + "RESERVATION_ID NUMBER NOT NULL, "
                + "SERVICE_ID NUMBER NOT NULL, "
                + "QUANTITY NUMBER DEFAULT 1, "
                + "CONSTRAINT FK_RES_SERVICE FOREIGN KEY (RESERVATION_ID) REFERENCES RESERVATIONS(RESERVATION_ID) ON DELETE CASCADE, "
                + "CONSTRAINT FK_SERVICE FOREIGN KEY (SERVICE_ID) REFERENCES SERVICES(SERVICE_ID))";
        stmt.execute(createReservationServices);
        System.out.println("Created RESERVATION_SERVICES table");
    }

    public static void insertSampleData() {
        Connection conn = null;
        Statement stmt = null;

        try {
            conn = DatabaseConnection.getInstance().getConnection();
            conn.setAutoCommit(false);

            stmt = conn.createStatement();

            System.out.println("Inserting sample data...");
            insertSampleUsers(stmt);
            insertSampleRooms(stmt);
            insertSampleServices(stmt);
            insertSampleReservations(stmt);
            insertSampleReservationServices(stmt);
            conn.commit();
            System.out.println("Sample data inserted successfully!");

        } catch (SQLException e) {
            System.err.println("Error inserting sample data!");
            e.printStackTrace();
            try {
                if (conn != null) {
                    conn.rollback();
                    System.out.println("Transaction rolled back.");
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        } finally {
            try {
                if (stmt != null) {
                    stmt.close();
                }
                if (conn != null) {
                    conn.setAutoCommit(true); // Re-enable auto-commit
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    private static void insertSampleUsers(Statement stmt) throws SQLException {

        stmt.execute("INSERT INTO USERS (USER_ID, USERNAME, PASSWORD, FULL_NAME, EMAIL, PHONE, ADDRESS, ROLE) "
                + "VALUES (USER_SEQ.NEXTVAL, 'admin', 'admin123', 'Ahmed Al-Mansour', 'admin@hotel.com', '0501234567', 'Hotel Main Office, Riyadh', 'ADMINISTRATOR')");
        stmt.execute("INSERT INTO USERS (USER_ID, USERNAME, PASSWORD, FULL_NAME, EMAIL, PHONE, ADDRESS, ROLE) "
                + "VALUES (USER_SEQ.NEXTVAL, 'receptionist1', 'recep123', 'Lama Al-Rasheed', 'lama@hotel.com', '0501234568', 'Hotel Reception, Riyadh', 'RECEPTIONIST')");

        stmt.execute("INSERT INTO USERS (USER_ID, USERNAME, PASSWORD, FULL_NAME, EMAIL, PHONE, ADDRESS, ROLE) "
                + "VALUES (USER_SEQ.NEXTVAL, 'receptionist2', 'recep123', 'Saad Al-Fahad', 'saad@hotel.com', '0501234569', 'Hotel Reception, Riyadh', 'RECEPTIONIST')");
        stmt.execute("INSERT INTO USERS (USER_ID, USERNAME, PASSWORD, FULL_NAME, EMAIL, PHONE, ADDRESS, ROLE) "
                + "VALUES (USER_SEQ.NEXTVAL, 'ali.omar', 'guest123', 'Ali Omar', 'ali.omar@email.com', '0551234567', 'King Fahad Road, Riyadh', 'GUEST')");

        stmt.execute("INSERT INTO USERS (USER_ID, USERNAME, PASSWORD, FULL_NAME, EMAIL, PHONE, ADDRESS, ROLE) "
                + "VALUES (USER_SEQ.NEXTVAL, 'lamia.ahmed', 'guest123', 'Lamia Ahmed', 'lamia.ahmed@email.com', '0551234568', 'Olaya Street, Riyadh', 'GUEST')");

        stmt.execute("INSERT INTO USERS (USER_ID, USERNAME, PASSWORD, FULL_NAME, EMAIL, PHONE, ADDRESS, ROLE) "
                + "VALUES (USER_SEQ.NEXTVAL, 'omar.khaled', 'guest123', 'Omar Khaled', 'omar.khaled@email.com', '0551234569', 'Al Malqa, Riyadh', 'GUEST')");

        System.out.println("Inserted sample users");
    }

    private static void insertSampleRooms(Statement stmt) throws SQLException {
        stmt.execute("INSERT INTO ROOMS (ROOM_ID, ROOM_NUMBER, ROOM_TYPE, PRICE_PER_NIGHT, CAPACITY, AMENITIES, STATUS, DESCRIPTION) "
                + "VALUES (ROOM_SEQ.NEXTVAL, '101', 'Single', 50.00, 1, 'WiFi, TV, Air Conditioning', 'AVAILABLE', 'Cozy single room with garden view')");

        stmt.execute("INSERT INTO ROOMS (ROOM_ID, ROOM_NUMBER, ROOM_TYPE, PRICE_PER_NIGHT, CAPACITY, AMENITIES, STATUS, DESCRIPTION) "
                + "VALUES (ROOM_SEQ.NEXTVAL, '102', 'Single', 50.00, 1, 'WiFi, TV, Air Conditioning', 'AVAILABLE', 'Comfortable single room')");

        stmt.execute("INSERT INTO ROOMS (ROOM_ID, ROOM_NUMBER, ROOM_TYPE, PRICE_PER_NIGHT, CAPACITY, AMENITIES, STATUS, DESCRIPTION) "
                + "VALUES (ROOM_SEQ.NEXTVAL, '103', 'Single', 55.00, 1, 'WiFi, TV, Air Conditioning, Mini Bar', 'AVAILABLE', 'Premium single room with mini bar')");
        stmt.execute("INSERT INTO ROOMS (ROOM_ID, ROOM_NUMBER, ROOM_TYPE, PRICE_PER_NIGHT, CAPACITY, AMENITIES, STATUS, DESCRIPTION) "
                + "VALUES (ROOM_SEQ.NEXTVAL, '201', 'Double', 80.00, 2, 'WiFi, TV, Air Conditioning, Balcony', 'AVAILABLE', 'Spacious double room with balcony')");

        stmt.execute("INSERT INTO ROOMS (ROOM_ID, ROOM_NUMBER, ROOM_TYPE, PRICE_PER_NIGHT, CAPACITY, AMENITIES, STATUS, DESCRIPTION) "
                + "VALUES (ROOM_SEQ.NEXTVAL, '202', 'Double', 80.00, 2, 'WiFi, TV, Air Conditioning', 'AVAILABLE', 'Comfortable double room')");

        stmt.execute("INSERT INTO ROOMS (ROOM_ID, ROOM_NUMBER, ROOM_TYPE, PRICE_PER_NIGHT, CAPACITY, AMENITIES, STATUS, DESCRIPTION) "
                + "VALUES (ROOM_SEQ.NEXTVAL, '203', 'Double', 85.00, 2, 'WiFi, TV, Air Conditioning, Mini Bar, Balcony', 'OCCUPIED', 'Premium double room with amenities')");
        stmt.execute("INSERT INTO ROOMS (ROOM_ID, ROOM_NUMBER, ROOM_TYPE, PRICE_PER_NIGHT, CAPACITY, AMENITIES, STATUS, DESCRIPTION) "
                + "VALUES (ROOM_SEQ.NEXTVAL, '301', 'Suite', 150.00, 4, 'WiFi, TV, Air Conditioning, Mini Bar, Jacuzzi, Living Room', 'AVAILABLE', 'Luxury suite with separate living area')");

        stmt.execute("INSERT INTO ROOMS (ROOM_ID, ROOM_NUMBER, ROOM_TYPE, PRICE_PER_NIGHT, CAPACITY, AMENITIES, STATUS, DESCRIPTION) "
                + "VALUES (ROOM_SEQ.NEXTVAL, '302', 'Suite', 150.00, 4, 'WiFi, TV, Air Conditioning, Mini Bar, Jacuzzi, Balcony', 'AVAILABLE', 'Luxury suite with ocean view')");
        stmt.execute("INSERT INTO ROOMS (ROOM_ID, ROOM_NUMBER, ROOM_TYPE, PRICE_PER_NIGHT, CAPACITY, AMENITIES, STATUS, DESCRIPTION) "
                + "VALUES (ROOM_SEQ.NEXTVAL, '401', 'Deluxe', 120.00, 3, 'WiFi, TV, Air Conditioning, Mini Bar, Balcony, Sofa', 'AVAILABLE', 'Deluxe room with extra space')");

        stmt.execute("INSERT INTO ROOMS (ROOM_ID, ROOM_NUMBER, ROOM_TYPE, PRICE_PER_NIGHT, CAPACITY, AMENITIES, STATUS, DESCRIPTION) "
                + "VALUES (ROOM_SEQ.NEXTVAL, '402', 'Deluxe', 120.00, 3, 'WiFi, TV, Air Conditioning, Mini Bar', 'MAINTENANCE', 'Deluxe room currently under maintenance')");

        System.out.println("Inserted sample rooms");
    }

    private static void insertSampleServices(Statement stmt) throws SQLException {
        stmt.execute("INSERT INTO SERVICES (SERVICE_ID, SERVICE_NAME, DESCRIPTION, PRICE) "
                + "VALUES (SERVICE_SEQ.NEXTVAL, 'Breakfast', 'Continental breakfast buffet', 15.00)");

        stmt.execute("INSERT INTO SERVICES (SERVICE_ID, SERVICE_NAME, DESCRIPTION, PRICE) "
                + "VALUES (SERVICE_SEQ.NEXTVAL, 'Parking', 'Secure parking space per day', 10.00)");

        stmt.execute("INSERT INTO SERVICES (SERVICE_ID, SERVICE_NAME, DESCRIPTION, PRICE) "
                + "VALUES (SERVICE_SEQ.NEXTVAL, 'Airport Transfer', 'Round trip airport shuttle service', 35.00)");

        stmt.execute("INSERT INTO SERVICES (SERVICE_ID, SERVICE_NAME, DESCRIPTION, PRICE) "
                + "VALUES (SERVICE_SEQ.NEXTVAL, 'Spa Treatment', 'One hour massage and spa treatment', 60.00)");

        stmt.execute("INSERT INTO SERVICES (SERVICE_ID, SERVICE_NAME, DESCRIPTION, PRICE) "
                + "VALUES (SERVICE_SEQ.NEXTVAL, 'Laundry', 'Laundry service per load', 20.00)");

        stmt.execute("INSERT INTO SERVICES (SERVICE_ID, SERVICE_NAME, DESCRIPTION, PRICE) "
                + "VALUES (SERVICE_SEQ.NEXTVAL, 'Room Service', '24/7 in-room dining service', 5.00)");

        System.out.println("Inserted sample services");
    }

    private static void insertSampleReservations(Statement stmt) throws SQLException {
        stmt.execute("INSERT INTO RESERVATIONS (RESERVATION_ID, GUEST_ID, ROOM_ID, CHECK_IN_DATE, CHECK_OUT_DATE, RESERVATION_DATE, STATUS, TOTAL_PRICE, NOTES) "
                + "VALUES (RESERVATION_SEQ.NEXTVAL, 4, 1, TO_DATE('2025-10-15', 'YYYY-MM-DD'), TO_DATE('2025-10-18', 'YYYY-MM-DD'), TO_DATE('2025-10-10', 'YYYY-MM-DD'), 'CHECKED_OUT', 150.00, 'Quiet room requested')");
        stmt.execute("INSERT INTO RESERVATIONS (RESERVATION_ID, GUEST_ID, ROOM_ID, CHECK_IN_DATE, CHECK_OUT_DATE, RESERVATION_DATE, STATUS, TOTAL_PRICE, NOTES) "
                + "VALUES (RESERVATION_SEQ.NEXTVAL, 5, 6, TO_DATE('2025-11-02', 'YYYY-MM-DD'), TO_DATE('2025-11-06', 'YYYY-MM-DD'), TO_DATE('2025-10-28', 'YYYY-MM-DD'), 'CHECKED_IN', 340.00, 'Anniversary celebration')");
        stmt.execute("INSERT INTO RESERVATIONS (RESERVATION_ID, GUEST_ID, ROOM_ID, CHECK_IN_DATE, CHECK_OUT_DATE, RESERVATION_DATE, STATUS, TOTAL_PRICE, NOTES) "
                + "VALUES (RESERVATION_SEQ.NEXTVAL, 6, 4, TO_DATE('2025-11-10', 'YYYY-MM-DD'), TO_DATE('2025-11-12', 'YYYY-MM-DD'), TO_DATE('2025-11-01', 'YYYY-MM-DD'), 'CONFIRMED', 160.00, 'Business trip')");
        stmt.execute("INSERT INTO RESERVATIONS (RESERVATION_ID, GUEST_ID, ROOM_ID, CHECK_IN_DATE, CHECK_OUT_DATE, RESERVATION_DATE, STATUS, TOTAL_PRICE, NOTES) "
                + "VALUES (RESERVATION_SEQ.NEXTVAL, 4, 7, TO_DATE('2025-11-20', 'YYYY-MM-DD'), TO_DATE('2025-11-25', 'YYYY-MM-DD'), TO_DATE('2025-11-03', 'YYYY-MM-DD'), 'PENDING', 750.00, 'Family vacation - needs confirmation')");

        System.out.println("Inserted sample reservations");
    }

    private static void insertSampleReservationServices(Statement stmt) throws SQLException {
        stmt.execute("INSERT INTO RESERVATION_SERVICES (RESERVATION_SERVICE_ID, RESERVATION_ID, SERVICE_ID, QUANTITY) "
                + "VALUES (RES_SERVICE_SEQ.NEXTVAL, 2, 1, 4)");

        stmt.execute("INSERT INTO RESERVATION_SERVICES (RESERVATION_SERVICE_ID, RESERVATION_ID, SERVICE_ID, QUANTITY) "
                + "VALUES (RES_SERVICE_SEQ.NEXTVAL, 2, 2, 1)");

        stmt.execute("INSERT INTO RESERVATION_SERVICES (RESERVATION_SERVICE_ID, RESERVATION_ID, SERVICE_ID, QUANTITY) "
                + "VALUES (RES_SERVICE_SEQ.NEXTVAL, 3, 1, 2)");

        stmt.execute("INSERT INTO RESERVATION_SERVICES (RESERVATION_SERVICE_ID, RESERVATION_ID, SERVICE_ID, QUANTITY) "
                + "VALUES (RES_SERVICE_SEQ.NEXTVAL, 4, 1, 5)");

        stmt.execute("INSERT INTO RESERVATION_SERVICES (RESERVATION_SERVICE_ID, RESERVATION_ID, SERVICE_ID, QUANTITY) "
                + "VALUES (RES_SERVICE_SEQ.NEXTVAL, 4, 2, 1)");

        stmt.execute("INSERT INTO RESERVATION_SERVICES (RESERVATION_SERVICE_ID, RESERVATION_ID, SERVICE_ID, QUANTITY) "
                + "VALUES (RES_SERVICE_SEQ.NEXTVAL, 4, 3, 1)");

        System.out.println("Inserted sample reservation services");
    }

    public static void main(String[] args) {
        System.out.println("=== Hotel Reservation System - Database Initializer ===\n");
        if (DatabaseConnection.getInstance().testConnection()) {
            System.out.println("Database connection successful!\n");
            initializeSchema();

            System.out.println();

            insertSampleData();

            System.out.println("\n=== Database initialization complete! ===");
        } else {
            System.err.println("Failed to connect to database!");
            System.err.println("Please check:");
            System.err.println("1. Oracle Database is running");
            System.err.println("2. Oracle JDBC driver (ojdbc8.jar) is in classpath");
            System.err.println("3. Database credentials are correct (system/1234)");
        }
    }
}
