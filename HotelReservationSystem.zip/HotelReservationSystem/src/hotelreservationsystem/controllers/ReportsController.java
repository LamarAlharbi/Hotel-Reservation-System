package hotelreservationsystem.controllers;

import hotelreservationsystem.dao.ReservationDAO;
import hotelreservationsystem.dao.RoomDAO;
import hotelreservationsystem.dao.UserDAO;
import java.sql.SQLException;
import hotelreservationsystem.models.Administrator;
import hotelreservationsystem.models.Reservation;
import hotelreservationsystem.models.Room;
import hotelreservationsystem.models.User;
import hotelreservationsystem.utils.AlertUtils;
import hotelreservationsystem.utils.Session;
import hotelreservationsystem.utils.ViewNavigator;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;

import java.util.ArrayList;

public class ReportsController {

    @FXML
    private Label totalUsersLabel;

    @FXML
    private Label totalRoomsLabel;

    @FXML
    private Label totalReservationsLabel;

    @FXML
    private Label totalRevenueLabel;

    @FXML
    private Label availableRoomsLabel;

    @FXML
    private Label occupiedRoomsLabel;

    @FXML
    private Label maintenanceRoomsLabel;

    @FXML
    private Label pendingReservationsLabel;

    @FXML
    private Label confirmedReservationsLabel;

    @FXML
    private Label checkedInReservationsLabel;

    @FXML
    private Label checkedOutReservationsLabel;

    @FXML
    private Label cancelledReservationsLabel;

    private UserDAO userDAO;
    private RoomDAO roomDAO;
    private ReservationDAO reservationDAO;
    private Administrator currentAdmin;

    @FXML
    public void initialize() {
        userDAO = new UserDAO();
        roomDAO = new RoomDAO();
        reservationDAO = new ReservationDAO();

        if (Session.getInstance().isLoggedIn() && Session.getInstance().isAdministrator()) {
            currentAdmin = (Administrator) Session.getInstance().getCurrentUser();
        } else {
            AlertUtils.showError("Access Denied", "You must be logged in as an administrator to access this page.");
            ViewNavigator.goToLogin();
            return;
        }

        loadStatistics();
    }

    private void loadStatistics() {
        try {
            ArrayList<User> users = userDAO.findAll();
            totalUsersLabel.setText(String.valueOf(users.size()));

            ArrayList<Room> rooms = roomDAO.findAll();
            totalRoomsLabel.setText(String.valueOf(rooms.size()));

            ArrayList<Reservation> reservations = reservationDAO.findAll();
            totalReservationsLabel.setText(String.valueOf(reservations.size()));

            double totalRevenue = reservationDAO.getTotalRevenue();
            totalRevenueLabel.setText(String.format("$%.2f", totalRevenue));

            long availableCount = rooms.stream()
                    .filter(room -> "AVAILABLE".equals(room.getStatus()))
                    .count();
            availableRoomsLabel.setText(String.valueOf(availableCount));

            long occupiedCount = rooms.stream()
                    .filter(room -> "OCCUPIED".equals(room.getStatus()))
                    .count();
            occupiedRoomsLabel.setText(String.valueOf(occupiedCount));

            long maintenanceCount = rooms.stream()
                    .filter(room -> "MAINTENANCE".equals(room.getStatus()))
                    .count();
            maintenanceRoomsLabel.setText(String.valueOf(maintenanceCount));

            long pendingCount = reservations.stream()
                    .filter(r -> "PENDING".equals(r.getStatus()))
                    .count();
            pendingReservationsLabel.setText(String.valueOf(pendingCount));

            long confirmedCount = reservations.stream()
                    .filter(r -> "CONFIRMED".equals(r.getStatus()))
                    .count();
            confirmedReservationsLabel.setText(String.valueOf(confirmedCount));

            long checkedInCount = reservations.stream()
                    .filter(r -> "CHECKED_IN".equals(r.getStatus()))
                    .count();
            checkedInReservationsLabel.setText(String.valueOf(checkedInCount));

            long checkedOutCount = reservations.stream()
                    .filter(r -> "CHECKED_OUT".equals(r.getStatus()))
                    .count();
            checkedOutReservationsLabel.setText(String.valueOf(checkedOutCount));

            long cancelledCount = reservations.stream()
                    .filter(r -> "CANCELLED".equals(r.getStatus()))
                    .count();
            cancelledReservationsLabel.setText(String.valueOf(cancelledCount));

        } catch (SQLException e) {
            AlertUtils.showDatabaseError("load statistics", e);
        }
    }

    @FXML
    private void handleRefresh(ActionEvent event) {
        loadStatistics();
        AlertUtils.showInfo("Refreshed", "All statistics have been refreshed successfully.");
    }

    @FXML
    private void handleBackToDashboard(ActionEvent event) {
        ViewNavigator.goToAdminDashboard();
    }
}
