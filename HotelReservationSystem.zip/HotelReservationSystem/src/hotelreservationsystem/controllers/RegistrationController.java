package hotelreservationsystem.controllers;

import hotelreservationsystem.dao.UserDAO;
import java.sql.SQLException;
import hotelreservationsystem.models.Guest;
import hotelreservationsystem.utils.AlertUtils;
import hotelreservationsystem.utils.ValidationUtils;
import hotelreservationsystem.utils.ViewNavigator;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;

public class RegistrationController {

    @FXML
    private TextField fullNameField;

    @FXML
    private TextField usernameField;

    @FXML
    private TextField emailField;

    @FXML
    private TextField phoneField;

    @FXML
    private TextField addressField;

    @FXML
    private PasswordField passwordField;

    @FXML
    private PasswordField confirmPasswordField;

    @FXML
    private Button registerButton;

    @FXML
    private Button cancelButton;

    @FXML
    private Hyperlink loginLink;

    private UserDAO userDAO;

    @FXML
    public void initialize() {
        userDAO = new UserDAO();
    }

    @FXML
    private void handleRegister(ActionEvent event) {
        String fullName = fullNameField.getText().trim();
        String username = usernameField.getText().trim();
        String email = emailField.getText().trim();
        String phone = phoneField.getText().trim();
        String address = addressField.getText().trim();
        String password = passwordField.getText();
        String confirmPassword = confirmPasswordField.getText();

        if (!validateInput(fullName, username, email, phone, address, password, confirmPassword)) {
            return;
        }
        try {
            if (userDAO.usernameExists(username)) {
                AlertUtils.showValidationError("Username already exists. Please choose a different username.");
                usernameField.requestFocus();
                return;
            }

            if (userDAO.emailExists(email)) {
                AlertUtils.showValidationError("Email already exists. Please use a different email address.");
                emailField.requestFocus();
                return;
            }

            Guest newGuest = new Guest(username, password, fullName, email, phone, address);

            Guest createdGuest = (Guest) userDAO.create(newGuest);

            if (createdGuest != null && createdGuest.getUserId() > 0) {
                AlertUtils.showSuccess("Registration Successful",
                        "Your account has been created successfully!\nYou can now login with your credentials.");

                ViewNavigator.goToLogin();
            } else {
                AlertUtils.showError("Registration Failed", "Failed to create account. Please try again.");
            }

        } catch (SQLException e) {
            AlertUtils.showDatabaseError("register user", e);
        }
    }

    @FXML
    private void handleCancel(ActionEvent event) {
        clearFields();
    }

    @FXML
    private void handleBackToLogin(ActionEvent event) {
        ViewNavigator.goToLogin();
    }

    private boolean validateInput(String fullName, String username, String email,
            String phone, String address, String password, String confirmPassword) {
        if (ValidationUtils.isEmpty(fullName)) {
            AlertUtils.showValidationError(ValidationUtils.getRequiredFieldMessage("Full Name"));
            fullNameField.requestFocus();
            return false;
        }

        if (ValidationUtils.isEmpty(username)) {
            AlertUtils.showValidationError(ValidationUtils.getRequiredFieldMessage("Username"));
            usernameField.requestFocus();
            return false;
        }

        if (!ValidationUtils.isValidUsername(username)) {
            AlertUtils.showValidationError(ValidationUtils.getInvalidUsernameMessage());
            usernameField.requestFocus();
            return false;
        }

        if (ValidationUtils.isEmpty(email)) {
            AlertUtils.showValidationError(ValidationUtils.getRequiredFieldMessage("Email"));
            emailField.requestFocus();
            return false;
        }

        if (!ValidationUtils.isValidEmail(email)) {
            AlertUtils.showValidationError(ValidationUtils.getInvalidEmailMessage());
            emailField.requestFocus();
            return false;
        }

        if (ValidationUtils.isEmpty(phone)) {
            AlertUtils.showValidationError(ValidationUtils.getRequiredFieldMessage("Phone"));
            phoneField.requestFocus();
            return false;
        }

        if (!ValidationUtils.isValidPhone(phone)) {
            AlertUtils.showValidationError(ValidationUtils.getInvalidPhoneMessage());
            phoneField.requestFocus();
            return false;
        }

        if (ValidationUtils.isEmpty(address)) {
            AlertUtils.showValidationError(ValidationUtils.getRequiredFieldMessage("Address"));
            addressField.requestFocus();
            return false;
        }

        if (ValidationUtils.isEmpty(password)) {
            AlertUtils.showValidationError(ValidationUtils.getRequiredFieldMessage("Password"));
            passwordField.requestFocus();
            return false;
        }

        if (!ValidationUtils.isValidPassword(password)) {
            AlertUtils.showValidationError(ValidationUtils.getWeakPasswordMessage());
            passwordField.requestFocus();
            return false;
        }

        if (ValidationUtils.isEmpty(confirmPassword)) {
            AlertUtils.showValidationError("Please confirm your password.");
            confirmPasswordField.requestFocus();
            return false;
        }

        if (!ValidationUtils.passwordsMatch(password, confirmPassword)) {
            AlertUtils.showValidationError(ValidationUtils.getPasswordMismatchMessage());
            confirmPasswordField.requestFocus();
            return false;
        }

        return true;
    }

    private void clearFields() {
        fullNameField.clear();
        usernameField.clear();
        emailField.clear();
        phoneField.clear();
        addressField.clear();
        passwordField.clear();
        confirmPasswordField.clear();
        fullNameField.requestFocus();
    }
}
