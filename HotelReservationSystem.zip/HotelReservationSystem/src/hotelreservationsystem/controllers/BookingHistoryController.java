package hotelreservationsystem.controllers;

import hotelreservationsystem.dao.ReservationDAO;
import java.sql.SQLException;
import hotelreservationsystem.models.Guest;
import hotelreservationsystem.models.Reservation;
import hotelreservationsystem.utils.AlertUtils;
import hotelreservationsystem.utils.Session;
import hotelreservationsystem.utils.ViewNavigator;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;

import java.time.LocalDate;
import java.util.ArrayList;

public class BookingHistoryController {

    @FXML
    private Label totalBookingsLabel;

    @FXML
    private Label cancelledBookingsLabel;

    @FXML
    private Label totalSpentLabel;

    @FXML
    private TableView<Reservation> historyTable;

    @FXML
    private TableColumn<Reservation, Integer> reservationIdCol;

    @FXML
    private TableColumn<Reservation, String> roomNumberCol;

    @FXML
    private TableColumn<Reservation, String> roomTypeCol;

    @FXML
    private TableColumn<Reservation, LocalDate> checkInCol;

    @FXML
    private TableColumn<Reservation, LocalDate> checkOutCol;

    @FXML
    private TableColumn<Reservation, LocalDate> reservationDateCol;

    @FXML
    private TableColumn<Reservation, String> statusCol;

    @FXML
    private TableColumn<Reservation, Double> totalPriceCol;

    @FXML
    private TableColumn<Reservation, Void> actionCol;

    private ReservationDAO reservationDAO;
    private Guest currentGuest;

    @FXML
    public void initialize() {
        reservationDAO = new ReservationDAO();
        if (Session.getInstance().isLoggedIn() && Session.getInstance().isGuest()) {
            currentGuest = (Guest) Session.getInstance().getCurrentUser();
        } else {
            AlertUtils.showError("Access Denied", "You must be logged in as a guest to access this page.");
            ViewNavigator.goToLogin();
            return;
        }
        setupTableColumns();
        loadBookingHistory();
        loadStatistics();
    }

    private void setupTableColumns() {
        reservationIdCol.setCellValueFactory(new PropertyValueFactory<>("reservationId"));
        checkInCol.setCellValueFactory(new PropertyValueFactory<>("checkInDate"));
        checkOutCol.setCellValueFactory(new PropertyValueFactory<>("checkOutDate"));
        reservationDateCol.setCellValueFactory(new PropertyValueFactory<>("reservationDate"));
        statusCol.setCellValueFactory(new PropertyValueFactory<>("status"));
        totalPriceCol.setCellValueFactory(new PropertyValueFactory<>("totalPrice"));
        roomNumberCol.setCellValueFactory(cellData -> {
            Reservation reservation = cellData.getValue();
            String roomNumber = (reservation.getRoom() != null) ? reservation.getRoom().getRoomNumber() : "N/A";
            return new javafx.beans.property.SimpleStringProperty(roomNumber);
        });
        roomTypeCol.setCellValueFactory(cellData -> {
            Reservation reservation = cellData.getValue();
            String roomType = (reservation.getRoom() != null) ? reservation.getRoom().getRoomType() : "N/A";
            return new javafx.beans.property.SimpleStringProperty(roomType);
        });
        totalPriceCol.setCellFactory(column -> new TableCell<Reservation, Double>() {
            @Override
            protected void updateItem(Double price, boolean empty) {
                super.updateItem(price, empty);
                if (empty || price == null) {
                    setText(null);
                } else {
                    setText(String.format("$%.2f", price));
                }
            }
        });
        actionCol.setCellFactory(column -> new TableCell<Reservation, Void>() {
            private final Button viewButton = new Button("View Details");

            {
                viewButton.setStyle("-fx-background-color: #3498db; -fx-text-fill: white;");
                viewButton.setOnAction(event -> {
                    Reservation reservation = getTableView().getItems().get(getIndex());
                    handleViewReservation(reservation);
                });
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) {
                    setGraphic(null);
                } else {
                    setGraphic(viewButton);
                }
            }
        });
    }

    private void loadBookingHistory() {
        try {
            ArrayList<Reservation> history = reservationDAO.findByGuestId(currentGuest.getUserId());
            ObservableList<Reservation> historyList = FXCollections.observableArrayList(history);
            historyTable.setItems(historyList);
        } catch (SQLException e) {
            AlertUtils.showDatabaseError("load booking history", e);
        }
    }

    private void loadStatistics() {
        try {
            ArrayList<Reservation> allReservations = reservationDAO.findByGuestId(currentGuest.getUserId());

            totalBookingsLabel.setText(String.valueOf(allReservations.size()));
            long cancelledCount = allReservations.stream()
                    .filter(r -> "CANCELLED".equals(r.getStatus()))
                    .count();
            cancelledBookingsLabel.setText(String.valueOf(cancelledCount));
            double totalSpent = allReservations.stream()
                    .filter(r -> !"CANCELLED".equals(r.getStatus()))
                    .mapToDouble(Reservation::getTotalPrice)
                    .sum();
            totalSpentLabel.setText(String.format("$%.2f", totalSpent));

        } catch (SQLException e) {
            AlertUtils.showDatabaseError("load statistics", e);
        }
    }

    private void handleViewReservation(Reservation reservation) {
        String roomNumber = (reservation.getRoom() != null) ? reservation.getRoom().getRoomNumber() : "N/A";
        String roomType = (reservation.getRoom() != null) ? reservation.getRoom().getRoomType() : "N/A";

        String details = String.format(
                "Reservation Details\n\n"
                + "Reservation ID: %d\n"
                + "Room Number: %s\n"
                + "Room Type: %s\n"
                + "Check-In Date: %s\n"
                + "Check-Out Date: %s\n"
                + "Reservation Date: %s\n"
                + "Status: %s\n"
                + "Total Price: $%.2f\n"
                + "Notes: %s",
                reservation.getReservationId(),
                roomNumber,
                roomType,
                reservation.getCheckInDate().toString(),
                reservation.getCheckOutDate().toString(),
                reservation.getReservationDate().toString(),
                reservation.getStatus(),
                reservation.getTotalPrice(),
                (reservation.getNotes() != null && !reservation.getNotes().isEmpty()) ? reservation.getNotes() : "None"
        );

        AlertUtils.showInfo("Reservation Details", details);
    }

    @FXML
    private void handleBackToDashboard(ActionEvent event) {
        ViewNavigator.goToGuestDashboard();
    }
}
