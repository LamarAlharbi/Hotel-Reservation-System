package hotelreservationsystem.controllers;

import hotelreservationsystem.dao.ReservationDAO;
import hotelreservationsystem.dao.RoomDAO;
import hotelreservationsystem.dao.UserDAO;
import java.sql.SQLException;
import hotelreservationsystem.models.Administrator;
import hotelreservationsystem.models.Reservation;
import hotelreservationsystem.models.Room;
import hotelreservationsystem.models.User;
import hotelreservationsystem.utils.AlertUtils;
import hotelreservationsystem.utils.Session;
import hotelreservationsystem.utils.ViewNavigator;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;

import java.util.ArrayList;

public class AdminDashboardController {

    @FXML
    private Label welcomeLabel;

    @FXML
    private Label totalUsersLabel;

    @FXML
    private Label totalRoomsLabel;

    @FXML
    private Label totalReservationsLabel;

    @FXML
    private Label totalRevenueLabel;

    @FXML
    private Button logoutButton;

    private UserDAO userDAO;
    private RoomDAO roomDAO;
    private ReservationDAO reservationDAO;
    private Administrator currentAdmin;

    @FXML
    public void initialize() {
        userDAO = new UserDAO();
        roomDAO = new RoomDAO();
        reservationDAO = new ReservationDAO();
        if (Session.getInstance().isLoggedIn() && Session.getInstance().isAdministrator()) {
            currentAdmin = (Administrator) Session.getInstance().getCurrentUser();
            welcomeLabel.setText("Welcome, " + currentAdmin.getFullName() + "!");
            loadStatistics();
        } else {
            AlertUtils.showError("Access Denied", "You must be logged in as an administrator to access this page.");
            ViewNavigator.goToLogin();
        }
    }

    private void loadStatistics() {
        try {
            ArrayList<User> users = userDAO.findAll();
            totalUsersLabel.setText(String.valueOf(users.size()));

            ArrayList<Room> rooms = roomDAO.findAll();
            totalRoomsLabel.setText(String.valueOf(rooms.size()));

            ArrayList<Reservation> reservations = reservationDAO.findAll();
            totalReservationsLabel.setText(String.valueOf(reservations.size()));

            double revenue = reservationDAO.getTotalRevenue();
            totalRevenueLabel.setText(String.format("$%.2f", revenue));

        } catch (SQLException e) {
            AlertUtils.showDatabaseError("load dashboard statistics", e);
        }
    }

    @FXML
    private void handleUserManagement(ActionEvent event) {
        ViewNavigator.goToUserManagement();
    }

    @FXML
    private void handleRoomConfig(ActionEvent event) {
        ViewNavigator.goToRoomConfiguration();
    }

    @FXML
    private void handleServicesConfig(ActionEvent event) {
        ViewNavigator.goToServicesConfiguration();
    }

    @FXML
    private void handleReports(ActionEvent event) {
        ViewNavigator.goToReports();
    }

    @FXML
    private void handleLogout(ActionEvent event) {
        if (AlertUtils.showConfirmation("Logout", "Are you sure you want to logout?")) {
            Session.getInstance().logout();
            ViewNavigator.goToLogin();
        }
    }
}
