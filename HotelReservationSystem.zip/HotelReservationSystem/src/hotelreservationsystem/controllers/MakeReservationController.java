package hotelreservationsystem.controllers;

import hotelreservationsystem.dao.ReservationDAO;
import java.sql.SQLException;
import hotelreservationsystem.models.Guest;
import hotelreservationsystem.models.Reservation;
import hotelreservationsystem.models.Room;
import hotelreservationsystem.utils.AlertUtils;
import hotelreservationsystem.utils.Session;
import hotelreservationsystem.utils.ViewNavigator;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class MakeReservationController {

    @FXML
    private Label roomNumberLabel;

    @FXML
    private Label roomTypeLabel;

    @FXML
    private Label priceLabel;

    @FXML
    private Label capacityLabel;

    @FXML
    private Label amenitiesLabel;

    @FXML
    private DatePicker checkInDatePicker;

    @FXML
    private DatePicker checkOutDatePicker;

    @FXML
    private Spinner<Integer> guestsSpinner;

    @FXML
    private TextArea notesArea;

    @FXML
    private Label totalPriceLabel;

    @FXML
    private Label nightsLabel;

    private ReservationDAO reservationDAO;
    private Guest currentGuest;
    private Room selectedRoom;

    @FXML
    public void initialize() {
        reservationDAO = new ReservationDAO();

        if (Session.getInstance().isLoggedIn() && Session.getInstance().isGuest()) {
            currentGuest = (Guest) Session.getInstance().getCurrentUser();
        } else {
            AlertUtils.showError("Access Denied", "You must be logged in as a guest to make a reservation.");
            ViewNavigator.goToLogin();
            return;
        }
        selectedRoom = (Room) Session.getInstance().getAttribute("selectedRoom");
        if (selectedRoom == null) {
            AlertUtils.showError("No Room Selected", "Please select a room first.");
            ViewNavigator.goToBrowseRooms();
            return;
        }

        displayRoomInfo();
        SpinnerValueFactory<Integer> valueFactory
                = new SpinnerValueFactory.IntegerSpinnerValueFactory(1, selectedRoom.getCapacity(), 1);
        guestsSpinner.setValueFactory(valueFactory);
        checkInDatePicker.setValue(LocalDate.now());
        checkOutDatePicker.setValue(LocalDate.now().plusDays(1));

        checkInDatePicker.valueProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal != null && checkOutDatePicker.getValue() != null) {
                if (newVal.isAfter(checkOutDatePicker.getValue()) || newVal.isEqual(checkOutDatePicker.getValue())) {
                    checkOutDatePicker.setValue(newVal.plusDays(1));
                }
            }
        });
    }

    private void displayRoomInfo() {
        roomNumberLabel.setText(String.valueOf(selectedRoom.getRoomNumber()));
        roomTypeLabel.setText(selectedRoom.getRoomType());
        priceLabel.setText(String.format("$%.2f", selectedRoom.getPricePerNight()));
        capacityLabel.setText(String.valueOf(selectedRoom.getCapacity()));
        amenitiesLabel.setText(selectedRoom.getAmenities());
    }

    @FXML
    private void handleCalculateTotal(ActionEvent event) {
        LocalDate checkIn = checkInDatePicker.getValue();
        LocalDate checkOut = checkOutDatePicker.getValue();

        if (checkIn == null || checkOut == null) {
            AlertUtils.showError("Invalid Dates", "Please select both check-in and check-out dates.");
            return;
        }

        if (checkIn.isBefore(LocalDate.now())) {
            AlertUtils.showError("Invalid Check-In Date", "Check-in date cannot be in the past.");
            return;
        }

        if (checkOut.isBefore(checkIn) || checkOut.isEqual(checkIn)) {
            AlertUtils.showError("Invalid Check-Out Date", "Check-out date must be after check-in date.");
            return;
        }

        long nights = ChronoUnit.DAYS.between(checkIn, checkOut);
        double totalPrice = nights * selectedRoom.getPricePerNight();

        nightsLabel.setText(nights + " night" + (nights > 1 ? "s" : ""));
        totalPriceLabel.setText(String.format("$%.2f", totalPrice));
    }

    @FXML
    private void handleConfirmReservation(ActionEvent event) {
        LocalDate checkIn = checkInDatePicker.getValue();
        LocalDate checkOut = checkOutDatePicker.getValue();
        int numberOfGuests = guestsSpinner.getValue();
        String notes = notesArea.getText().trim();
        if (checkIn == null || checkOut == null) {
            AlertUtils.showError("Invalid Dates", "Please select both check-in and check-out dates.");
            return;
        }

        if (checkIn.isBefore(LocalDate.now())) {
            AlertUtils.showError("Invalid Check-In Date", "Check-in date cannot be in the past.");
            return;
        }

        if (checkOut.isBefore(checkIn) || checkOut.isEqual(checkIn)) {
            AlertUtils.showError("Invalid Check-Out Date", "Check-out date must be after check-in date.");
            return;
        }

        long nights = ChronoUnit.DAYS.between(checkIn, checkOut);
        double totalPrice = nights * selectedRoom.getPricePerNight();

        Reservation reservation = new Reservation();
        reservation.setGuest(currentGuest);
        reservation.setRoom(selectedRoom);
        reservation.setCheckInDate(java.sql.Date.valueOf(checkIn));
        reservation.setCheckOutDate(java.sql.Date.valueOf(checkOut));
        reservation.setReservationDate(java.sql.Date.valueOf(LocalDate.now()));
        reservation.setStatus("CONFIRMED");
        reservation.setTotalPrice(totalPrice);
        reservation.setNotes(notes.isEmpty() ? null : notes);

        String confirmMessage = String.format(
                "Room: %s (%s)\nCheck-In: %s\nCheck-Out: %s\nNights: %d\nGuests: %d\nTotal: $%.2f\n\nConfirm reservation?",
                selectedRoom.getRoomNumber(),
                selectedRoom.getRoomType(),
                checkIn.toString(),
                checkOut.toString(),
                nights,
                numberOfGuests,
                totalPrice
        );

        if (!AlertUtils.showConfirmation("Confirm Reservation", confirmMessage)) {
            return;
        }

        try {
            Reservation created = reservationDAO.create(reservation);
            if (created != null) {
                Session.getInstance().removeAttribute("selectedRoom");
                AlertUtils.showInfo("Success", "Reservation confirmed successfully!\nReservation ID: " + created.getReservationId());
                ViewNavigator.goToMyReservations();
            } else {
                AlertUtils.showError("Reservation Failed", "Failed to create reservation. Please try again.");
            }
        } catch (SQLException e) {
            AlertUtils.showDatabaseError("create reservation", e);
        }
    }

    @FXML
    private void handleCancel(ActionEvent event) {
        if (AlertUtils.showConfirmation("Cancel", "Are you sure you want to cancel this reservation?")) {
            Session.getInstance().removeAttribute("selectedRoom");
            ViewNavigator.goToBrowseRooms();
        }
    }

    @FXML
    private void handleBackToBrowse(ActionEvent event) {
        Session.getInstance().removeAttribute("selectedRoom");
        ViewNavigator.goToBrowseRooms();
    }
}
