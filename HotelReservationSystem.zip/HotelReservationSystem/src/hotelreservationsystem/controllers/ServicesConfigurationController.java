package hotelreservationsystem.controllers;

import hotelreservationsystem.dao.ServiceDAO;
import java.sql.SQLException;
import hotelreservationsystem.models.Administrator;
import hotelreservationsystem.models.Service;
import hotelreservationsystem.utils.AlertUtils;
import hotelreservationsystem.utils.Session;
import hotelreservationsystem.utils.ViewNavigator;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;

import java.util.ArrayList;
import java.util.Optional;

public class ServicesConfigurationController {

    @FXML
    private TableView<Service> servicesTable;

    @FXML
    private TableColumn<Service, Integer> serviceIdCol;

    @FXML
    private TableColumn<Service, String> serviceNameCol;

    @FXML
    private TableColumn<Service, String> descriptionCol;

    @FXML
    private TableColumn<Service, Double> priceCol;

    @FXML
    private TableColumn<Service, Void> actionCol;

    private ServiceDAO serviceDAO;
    private Administrator currentAdmin;
    private ObservableList<Service> allServices;

    @FXML
    public void initialize() {
        serviceDAO = new ServiceDAO();

        if (Session.getInstance().isLoggedIn() && Session.getInstance().isAdministrator()) {
            currentAdmin = (Administrator) Session.getInstance().getCurrentUser();
        } else {
            AlertUtils.showError("Access Denied", "You must be logged in as an administrator to access this page.");
            ViewNavigator.goToLogin();
            return;
        }

        setupTableColumns();
        loadServices();
    }

  
    private void setupTableColumns() {
        serviceIdCol.setCellValueFactory(new PropertyValueFactory<>("serviceId"));
        serviceNameCol.setCellValueFactory(new PropertyValueFactory<>("serviceName"));
        descriptionCol.setCellValueFactory(new PropertyValueFactory<>("description"));
        priceCol.setCellValueFactory(new PropertyValueFactory<>("price"));

        priceCol.setCellFactory(column -> new TableCell<Service, Double>() {
            @Override
            protected void updateItem(Double price, boolean empty) {
                super.updateItem(price, empty);
                if (empty || price == null) {
                    setText(null);
                } else {
                    setText(String.format("$%.2f", price));
                }
            }
        });

        actionCol.setCellFactory(column -> new TableCell<Service, Void>() {
            private final Button editButton = new Button("Edit");
            private final Button deleteButton = new Button("Delete");

            {
                editButton.setStyle("-fx-background-color: #3498db; -fx-text-fill: white; -fx-font-size: 10;");
                deleteButton.setStyle("-fx-background-color: #e74c3c; -fx-text-fill: white; -fx-font-size: 10;");

                editButton.setOnAction(event -> {
                    Service service = getTableView().getItems().get(getIndex());
                    handleEditService(service);
                });

                deleteButton.setOnAction(event -> {
                    Service service = getTableView().getItems().get(getIndex());
                    handleDeleteService(service);
                });
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) {
                    setGraphic(null);
                } else {
                    HBox buttons = new HBox(5);
                    buttons.setAlignment(Pos.CENTER);
                    buttons.getChildren().addAll(editButton, deleteButton);
                    setGraphic(buttons);
                }
            }
        });
    }

    private void loadServices() {
        try {
            ArrayList<Service> services = serviceDAO.findAll();
            allServices = FXCollections.observableArrayList(services);
            servicesTable.setItems(allServices);
        } catch (SQLException e) {
            AlertUtils.showDatabaseError("load services", e);
        }
    }

    @FXML
    private void handleRefresh(ActionEvent event) {
        loadServices();
    }

    @FXML
    private void handleAddService(ActionEvent event) {
        Dialog<Service> dialog = new Dialog<>();
        dialog.setTitle("Add New Service");
        dialog.setHeaderText("Enter new service information");

        ButtonType saveButtonType = new ButtonType("Save", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(saveButtonType, ButtonType.CANCEL);

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20, 150, 10, 10));

        TextField serviceNameField = new TextField();
        TextArea descriptionArea = new TextArea();
        descriptionArea.setPrefRowCount(3);
        TextField priceField = new TextField();

        grid.add(new Label("Service Name:"), 0, 0);
        grid.add(serviceNameField, 1, 0);
        grid.add(new Label("Description:"), 0, 1);
        grid.add(descriptionArea, 1, 1);
        grid.add(new Label("Price:"), 0, 2);
        grid.add(priceField, 1, 2);

        dialog.getDialogPane().setContent(grid);

        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == saveButtonType) {
                String serviceName = serviceNameField.getText().trim();
                String description = descriptionArea.getText().trim();
                String priceText = priceField.getText().trim();

                if (serviceName.isEmpty() || description.isEmpty() || priceText.isEmpty()) {
                    AlertUtils.showError("Validation Error", "All fields are required.");
                    return null;
                }

                try {
                    double price = Double.parseDouble(priceText);
                    if (price <= 0) {
                        AlertUtils.showError("Invalid Price", "Price must be a positive number.");
                        return null;
                    }

                    Service newService = new Service();
                    newService.setServiceName(serviceName);
                    newService.setDescription(description);
                    newService.setPrice(price);

                    return newService;
                } catch (NumberFormatException e) {
                    AlertUtils.showError("Invalid Input", "Please enter a valid number for price.");
                    return null;
                }
            }
            return null;
        });

        Optional<Service> result = dialog.showAndWait();
        result.ifPresent(service -> {
            try {
                Service created = serviceDAO.create(service);
                if (created != null) {
                    AlertUtils.showInfo("Success", "Service created successfully!");
                    loadServices();
                } else {
                    AlertUtils.showError("Creation Failed", "Failed to create service.");
                }
            } catch (SQLException e) {
                AlertUtils.showDatabaseError("create service", e);
            }
        });
    }

    private void handleEditService(Service service) {
        Dialog<Service> dialog = new Dialog<>();
        dialog.setTitle("Edit Service");
        dialog.setHeaderText("Edit service information");

        ButtonType saveButtonType = new ButtonType("Save", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(saveButtonType, ButtonType.CANCEL);

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20, 150, 10, 10));

        TextField serviceNameField = new TextField(service.getServiceName());
        TextArea descriptionArea = new TextArea(service.getDescription());
        descriptionArea.setPrefRowCount(3);
        TextField priceField = new TextField(String.valueOf(service.getPrice()));

        grid.add(new Label("Service Name:"), 0, 0);
        grid.add(serviceNameField, 1, 0);
        grid.add(new Label("Description:"), 0, 1);
        grid.add(descriptionArea, 1, 1);
        grid.add(new Label("Price:"), 0, 2);
        grid.add(priceField, 1, 2);

        dialog.getDialogPane().setContent(grid);

        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == saveButtonType) {
                String serviceName = serviceNameField.getText().trim();
                String description = descriptionArea.getText().trim();
                String priceText = priceField.getText().trim();

                if (serviceName.isEmpty() || description.isEmpty() || priceText.isEmpty()) {
                    AlertUtils.showError("Validation Error", "All fields are required.");
                    return null;
                }

                try {
                    double price = Double.parseDouble(priceText);
                    if (price <= 0) {
                        AlertUtils.showError("Invalid Price", "Price must be a positive number.");
                        return null;
                    }

                    service.setServiceName(serviceName);
                    service.setDescription(description);
                    service.setPrice(price);

                    return service;
                } catch (NumberFormatException e) {
                    AlertUtils.showError("Invalid Input", "Please enter a valid number for price.");
                    return null;
                }
            }
            return null;
        });

        Optional<Service> result = dialog.showAndWait();
        result.ifPresent(updatedService -> {
            try {
                if (serviceDAO.update(updatedService)) {
                    AlertUtils.showInfo("Success", "Service updated successfully!");
                    loadServices();
                } else {
                    AlertUtils.showError("Update Failed", "Failed to update service.");
                }
            } catch (SQLException e) {
                AlertUtils.showDatabaseError("update service", e);
            }
        });
    }


    private void handleDeleteService(Service service) {
        String message = String.format("Are you sure you want to delete service '%s'?", service.getServiceName());
        if (AlertUtils.showConfirmation("Delete Service", message)) {
            try {
                if (serviceDAO.deplete(service.getServiceId())) {
                    AlertUtils.showInfo("Success", "Service deleted successfully.");
                    loadServices();
                } else {
                    AlertUtils.showError("Deletion Failed", "Failed to delete service.");
                }
            } catch (SQLException e) {
                AlertUtils.showDatabaseError("delete service", e);
            }
        }
    }

 
    @FXML
    private void handleBackToDashboard(ActionEvent event) {
        ViewNavigator.goToAdminDashboard();
    }
}
