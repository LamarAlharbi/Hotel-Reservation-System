package hotelreservationsystem.controllers;

import hotelreservationsystem.dao.ReservationDAO;
import java.sql.SQLException;
import hotelreservationsystem.models.Guest;
import hotelreservationsystem.models.Reservation;
import hotelreservationsystem.utils.AlertUtils;
import hotelreservationsystem.utils.Session;
import hotelreservationsystem.utils.ViewNavigator;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;

import java.time.LocalDate;
import java.util.ArrayList;

public class MyReservationsController {

    @FXML
    private TableView<Reservation> reservationsTable;

    @FXML
    private TableColumn<Reservation, Integer> reservationIdCol;

    @FXML
    private TableColumn<Reservation, String> roomNumberCol;

    @FXML
    private TableColumn<Reservation, String> roomTypeCol;

    @FXML
    private TableColumn<Reservation, LocalDate> checkInCol;

    @FXML
    private TableColumn<Reservation, LocalDate> checkOutCol;

    @FXML
    private TableColumn<Reservation, LocalDate> reservationDateCol;

    @FXML
    private TableColumn<Reservation, String> statusCol;

    @FXML
    private TableColumn<Reservation, Double> totalPriceCol;

    @FXML
    private TableColumn<Reservation, Void> actionCol;

    private ReservationDAO reservationDAO;
    private Guest currentGuest;
    private ObservableList<Reservation> allReservations;

    @FXML
    public void initialize() {
        reservationDAO = new ReservationDAO();

        if (Session.getInstance().isLoggedIn() && Session.getInstance().isGuest()) {
            currentGuest = (Guest) Session.getInstance().getCurrentUser();
        } else {
            AlertUtils.showError("Access Denied", "You must be logged in as a guest to access this page.");
            ViewNavigator.goToLogin();
            return;
        }

        setupTableColumns();

        loadReservations();
    }

    private void setupTableColumns() {
        reservationIdCol.setCellValueFactory(new PropertyValueFactory<>("reservationId"));
        checkInCol.setCellValueFactory(new PropertyValueFactory<>("checkInDate"));
        checkOutCol.setCellValueFactory(new PropertyValueFactory<>("checkOutDate"));
        reservationDateCol.setCellValueFactory(new PropertyValueFactory<>("reservationDate"));
        statusCol.setCellValueFactory(new PropertyValueFactory<>("status"));
        totalPriceCol.setCellValueFactory(new PropertyValueFactory<>("totalPrice"));

        roomNumberCol.setCellValueFactory(cellData -> {
            Reservation reservation = cellData.getValue();
            String roomNumber = (reservation.getRoom() != null) ? reservation.getRoom().getRoomNumber() : "N/A";
            return new javafx.beans.property.SimpleStringProperty(roomNumber);
        });

        roomTypeCol.setCellValueFactory(cellData -> {
            Reservation reservation = cellData.getValue();
            String roomType = (reservation.getRoom() != null) ? reservation.getRoom().getRoomType() : "N/A";
            return new javafx.beans.property.SimpleStringProperty(roomType);
        });
        totalPriceCol.setCellFactory(column -> new TableCell<Reservation, Double>() {
            @Override
            protected void updateItem(Double price, boolean empty) {
                super.updateItem(price, empty);
                if (empty || price == null) {
                    setText(null);
                } else {
                    setText(String.format("$%.2f", price));
                }
            }
        });
        actionCol.setCellFactory(column -> new TableCell<Reservation, Void>() {
            private final Button cancelButton = new Button("Cancel");
            private final Button viewButton = new Button("View");

            {
                cancelButton.setStyle("-fx-background-color: #e74c3c; -fx-text-fill: white;");
                viewButton.setStyle("-fx-background-color: #3498db; -fx-text-fill: white;");

                cancelButton.setOnAction(event -> {
                    Reservation reservation = getTableView().getItems().get(getIndex());
                    handleCancelReservation(reservation);
                });

                viewButton.setOnAction(event -> {
                    Reservation reservation = getTableView().getItems().get(getIndex());
                    handleViewReservation(reservation);
                });
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) {
                    setGraphic(null);
                } else {
                    Reservation reservation = getTableView().getItems().get(getIndex());
                    HBox buttons = new HBox(5);
                    if ("PENDING".equals(reservation.getStatus()) || "CONFIRMED".equals(reservation.getStatus())) {
                        buttons.getChildren().add(cancelButton);
                    }

                    buttons.getChildren().add(viewButton);
                    setGraphic(buttons);
                }
            }
        });
    }

    private void loadReservations() {
        try {
            ArrayList<Reservation> reservations = reservationDAO.findByGuestId(currentGuest.getUserId());
            allReservations = FXCollections.observableArrayList(reservations);
            reservationsTable.setItems(allReservations);
        } catch (SQLException e) {
            AlertUtils.showDatabaseError("load reservations", e);
        }
    }

    @FXML
    private void handleRefresh(ActionEvent event) {
        loadReservations();
    }

    private void handleCancelReservation(Reservation reservation) {
        String roomNumber = (reservation.getRoom() != null) ? reservation.getRoom().getRoomNumber() : "N/A";

        String message = String.format(
                "Are you sure you want to cancel this reservation?\n\nReservation ID: %d\nRoom: %s\nCheck-In: %s\nCheck-Out: %s",
                reservation.getReservationId(),
                roomNumber,
                reservation.getCheckInDate().toString(),
                reservation.getCheckOutDate().toString()
        );

        if (AlertUtils.showConfirmation("Cancel Reservation", message)) {
            try {
                reservation.setStatus("CANCELLED");
                if (reservationDAO.update(reservation)) {
                    AlertUtils.showInfo("Success", "Reservation cancelled successfully.");
                    loadReservations();
                } else {
                    AlertUtils.showError("Cancellation Failed", "Failed to cancel reservation. Please try again.");
                }
            } catch (SQLException e) {
                AlertUtils.showDatabaseError("cancel reservation", e);
            }
        }
    }

    private void handleViewReservation(Reservation reservation) {
        String roomNumber = (reservation.getRoom() != null) ? reservation.getRoom().getRoomNumber() : "N/A";
        String roomType = (reservation.getRoom() != null) ? reservation.getRoom().getRoomType() : "N/A";

        String details = String.format(
                "Reservation Details\n\n"
                + "Reservation ID: %d\n"
                + "Room Number: %s\n"
                + "Room Type: %s\n"
                + "Check-In Date: %s\n"
                + "Check-Out Date: %s\n"
                + "Reservation Date: %s\n"
                + "Status: %s\n"
                + "Total Price: $%.2f\n"
                + "Notes: %s",
                reservation.getReservationId(),
                roomNumber,
                roomType,
                reservation.getCheckInDate().toString(),
                reservation.getCheckOutDate().toString(),
                reservation.getReservationDate().toString(),
                reservation.getStatus(),
                reservation.getTotalPrice(),
                (reservation.getNotes() != null && !reservation.getNotes().isEmpty()) ? reservation.getNotes() : "None"
        );

        AlertUtils.showInfo("Reservation Details", details);
    }

    @FXML
    private void handleBackToDashboard(ActionEvent event) {
        ViewNavigator.goToGuestDashboard();
    }
}
