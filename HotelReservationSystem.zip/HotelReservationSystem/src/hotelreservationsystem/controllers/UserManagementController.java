package hotelreservationsystem.controllers;

import hotelreservationsystem.dao.UserDAO;
import hotelreservationsystem.dao.ReservationDAO;
import java.sql.SQLException;
import hotelreservationsystem.models.Administrator;
import hotelreservationsystem.models.User;
import hotelreservationsystem.models.Reservation;
import hotelreservationsystem.utils.AlertUtils;
import hotelreservationsystem.utils.Session;
import hotelreservationsystem.utils.ValidationUtils;
import hotelreservationsystem.utils.ViewNavigator;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Optional;
import java.util.stream.Collectors;

public class UserManagementController {

    @FXML
    private TableView<User> usersTable;

    @FXML
    private TableColumn<User, Integer> userIdCol;

    @FXML
    private TableColumn<User, String> usernameCol;

    @FXML
    private TableColumn<User, String> fullNameCol;

    @FXML
    private TableColumn<User, String> emailCol;

    @FXML
    private TableColumn<User, String> phoneCol;

    @FXML
    private TableColumn<User, String> roleCol;

    @FXML
    private TableColumn<User, LocalDate> createdDateCol;

    @FXML
    private TableColumn<User, Void> actionCol;

    private UserDAO userDAO;
    private ReservationDAO reservationDAO;
    private Administrator currentAdmin;
    private ObservableList<User> allUsers;

    @FXML
    public void initialize() {
        userDAO = new UserDAO();
        reservationDAO = new ReservationDAO();

        // Check if user is logged in as administrator
        if (Session.getInstance().isLoggedIn() && Session.getInstance().isAdministrator()) {
            currentAdmin = (Administrator) Session.getInstance().getCurrentUser();
        } else {
            AlertUtils.showError("Access Denied", "You must be logged in as an administrator to access this page.");
            ViewNavigator.goToLogin();
            return;
        }

        setupTableColumns();
        loadUsers();
    }

    private void setupTableColumns() {
        userIdCol.setCellValueFactory(new PropertyValueFactory<>("userId"));
        usernameCol.setCellValueFactory(new PropertyValueFactory<>("username"));
        fullNameCol.setCellValueFactory(new PropertyValueFactory<>("fullName"));
        emailCol.setCellValueFactory(new PropertyValueFactory<>("email"));
        phoneCol.setCellValueFactory(new PropertyValueFactory<>("phone"));
        roleCol.setCellValueFactory(new PropertyValueFactory<>("role"));
        createdDateCol.setCellValueFactory(new PropertyValueFactory<>("createdDate"));

        actionCol.setCellFactory(column -> new TableCell<User, Void>() {
            private final Button editButton = new Button("Edit");
            private final Button deleteButton = new Button("Delete");

            {
                editButton.setStyle("-fx-background-color: #3498db; -fx-text-fill: white; -fx-font-size: 10;");
                deleteButton.setStyle("-fx-background-color: #e74c3c; -fx-text-fill: white; -fx-font-size: 10;");

                editButton.setOnAction(event -> {
                    User user = getTableView().getItems().get(getIndex());
                    handleEditUser(user);
                });

                deleteButton.setOnAction(event -> {
                    User user = getTableView().getItems().get(getIndex());
                    handleDeleteUser(user);
                });
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) {
                    setGraphic(null);
                } else {
                    User user = getTableView().getItems().get(getIndex());
                    HBox buttons = new HBox(5);
                    buttons.setAlignment(Pos.CENTER);
                    buttons.getChildren().addAll(editButton, deleteButton);

                    // Don't allow deleting current admin
                    if (user.getUserId() == currentAdmin.getUserId()) {
                        deleteButton.setDisable(true);
                    }

                    setGraphic(buttons);
                }
            }
        });
    }

    private void loadUsers() {
        try {
            ArrayList<User> users = userDAO.findAll();
            allUsers = FXCollections.observableArrayList(users);
            usersTable.setItems(allUsers);
        } catch (SQLException e) {
            AlertUtils.showDatabaseError("load users", e);
        }
    }

    @FXML
    private void handleRefresh(ActionEvent event) {
        loadUsers();
    }

    @FXML
    private void handleAddUser(ActionEvent event) {
        Dialog<User> dialog = new Dialog<>();
        dialog.setTitle("Add New User");
        dialog.setHeaderText("Enter new user information");

        ButtonType saveButtonType = new ButtonType("Save", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(saveButtonType, ButtonType.CANCEL);

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20, 150, 10, 10));

        TextField usernameField = new TextField();
        PasswordField passwordField = new PasswordField();
        TextField fullNameField = new TextField();
        TextField emailField = new TextField();
        TextField phoneField = new TextField();
        TextField addressField = new TextField();
        ComboBox<String> roleCombo = new ComboBox<>();
        roleCombo.setItems(FXCollections.observableArrayList("GUEST", "RECEPTIONIST", "ADMINISTRATOR"));
        roleCombo.getSelectionModel().selectFirst();

        grid.add(new Label("Username:"), 0, 0);
        grid.add(usernameField, 1, 0);
        grid.add(new Label("Password:"), 0, 1);
        grid.add(passwordField, 1, 1);
        grid.add(new Label("Full Name:"), 0, 2);
        grid.add(fullNameField, 1, 2);
        grid.add(new Label("Email:"), 0, 3);
        grid.add(emailField, 1, 3);
        grid.add(new Label("Phone:"), 0, 4);
        grid.add(phoneField, 1, 4);
        grid.add(new Label("Address:"), 0, 5);
        grid.add(addressField, 1, 5);
        grid.add(new Label("Role:"), 0, 6);
        grid.add(roleCombo, 1, 6);

        dialog.getDialogPane().setContent(grid);

        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == saveButtonType) {
                String username = usernameField.getText().trim();
                String password = passwordField.getText();
                String fullName = fullNameField.getText().trim();
                String email = emailField.getText().trim();
                String phone = phoneField.getText().trim();
                String address = addressField.getText().trim();
                String role = roleCombo.getValue();

                // Validate inputs
                if (username.isEmpty() || password.isEmpty() || fullName.isEmpty() || email.isEmpty() || phone.isEmpty()) {
                    AlertUtils.showError("Validation Error", "All fields except address are required.");
                    return null;
                }

                if (!ValidationUtils.isValidEmail(email)) {
                    AlertUtils.showError("Invalid Email", "Please enter a valid email address.");
                    return null;
                }

                if (!ValidationUtils.isValidPhone(phone)) {
                    AlertUtils.showError("Invalid Phone", "Please enter a valid phone number.");
                    return null;
                }

                if (!ValidationUtils.isValidPassword(password)) {
                    AlertUtils.showError("Invalid Password", "Password must be at least 6 characters long.");
                    return null;
                }

                User newUser = new User();
                newUser.setUsername(username);
                newUser.setPassword(password);
                newUser.setFullName(fullName);
                newUser.setEmail(email);
                newUser.setPhone(phone);
                newUser.setAddress(address.isEmpty() ? null : address);
                newUser.setRole(role);
                newUser.setCreatedDate(java.sql.Date.valueOf(LocalDate.now()));

                return newUser;
            }
            return null;
        });

        Optional<User> result = dialog.showAndWait();
        result.ifPresent(user -> {
            try {
                User created = userDAO.create(user);
                if (created != null) {
                    AlertUtils.showInfo("Success", "User created successfully!");
                    loadUsers();
                } else {
                    AlertUtils.showError("Creation Failed", "Failed to create user. Username may already exist.");
                }
            } catch (SQLException e) {
                AlertUtils.showDatabaseError("create user", e);
            }
        });
    }

    private void handleEditUser(User user) {
        Dialog<User> dialog = new Dialog<>();
        dialog.setTitle("Edit User");
        dialog.setHeaderText("Edit user information");

        ButtonType saveButtonType = new ButtonType("Save", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(saveButtonType, ButtonType.CANCEL);

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20, 150, 10, 10));

        TextField fullNameField = new TextField(user.getFullName());
        TextField emailField = new TextField(user.getEmail());
        TextField phoneField = new TextField(user.getPhone());
        TextField addressField = new TextField(user.getAddress() != null ? user.getAddress() : "");
        ComboBox<String> roleCombo = new ComboBox<>();
        roleCombo.setItems(FXCollections.observableArrayList("GUEST", "RECEPTIONIST", "ADMINISTRATOR"));
        roleCombo.setValue(user.getRole());

        grid.add(new Label("Username:"), 0, 0);
        grid.add(new Label(user.getUsername()), 1, 0);
        grid.add(new Label("Full Name:"), 0, 1);
        grid.add(fullNameField, 1, 1);
        grid.add(new Label("Email:"), 0, 2);
        grid.add(emailField, 1, 2);
        grid.add(new Label("Phone:"), 0, 3);
        grid.add(phoneField, 1, 3);
        grid.add(new Label("Address:"), 0, 4);
        grid.add(addressField, 1, 4);
        grid.add(new Label("Role:"), 0, 5);
        grid.add(roleCombo, 1, 5);

        dialog.getDialogPane().setContent(grid);

        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == saveButtonType) {
                String fullName = fullNameField.getText().trim();
                String email = emailField.getText().trim();
                String phone = phoneField.getText().trim();
                String address = addressField.getText().trim();
                String role = roleCombo.getValue();

                if (fullName.isEmpty() || email.isEmpty() || phone.isEmpty()) {
                    AlertUtils.showError("Validation Error", "Full Name, Email, and Phone are required.");
                    return null;
                }

                if (!ValidationUtils.isValidEmail(email)) {
                    AlertUtils.showError("Invalid Email", "Please enter a valid email address.");
                    return null;
                }

                if (!ValidationUtils.isValidPhone(phone)) {
                    AlertUtils.showError("Invalid Phone", "Please enter a valid phone number.");
                    return null;
                }

                user.setFullName(fullName);
                user.setEmail(email);
                user.setPhone(phone);
                user.setAddress(address.isEmpty() ? null : address);
                user.setRole(role);

                return user;
            }
            return null;
        });

        Optional<User> result = dialog.showAndWait();
        result.ifPresent(updatedUser -> {
            try {
                if (userDAO.update(updatedUser)) {
                    AlertUtils.showInfo("Success", "User updated successfully!");
                    loadUsers();
                } else {
                    AlertUtils.showError("Update Failed", "Failed to update user.");
                }
            } catch (SQLException e) {
                AlertUtils.showDatabaseError("update user", e);
            }
        });
    }

    private void handleDeleteUser(User user) {
        if (user.getUserId() == currentAdmin.getUserId()) {
            AlertUtils.showError("Cannot Delete", "You cannot delete your own account.");
            return;
        }

        try {
            ArrayList<Reservation> userReservations = reservationDAO.findByGuestId(user.getUserId());
            if (userReservations != null && !userReservations.isEmpty()) {
                long activeReservations = userReservations.stream()
                        .filter(r -> !"CHECKED_OUT".equals(r.getStatus()) && !"CANCELLED".equals(r.getStatus()))
                        .count();

                if (activeReservations > 0) {
                    AlertUtils.showError("Cannot Delete User",
                            String.format("Cannot delete user '%s' because they have %d active reservation(s). "
                                    + "Please cancel or complete all reservations first.",
                                    user.getFullName(), activeReservations));
                } else {
                    AlertUtils.showError("Cannot Delete User",
                            String.format("Cannot delete user '%s' because they have reservation history in the system. "
                                    + "Deleting users with reservation records is not allowed to maintain data integrity.",
                                    user.getFullName()));
                }
                return;
            }
        } catch (SQLException e) {
            AlertUtils.showDatabaseError("check user reservations", e);
            return;
        }

        String message = String.format("Are you sure you want to delete user '%s' (%s)?", user.getFullName(), user.getUsername());
        if (AlertUtils.showConfirmation("Delete User", message)) {
            try {
                if (userDAO.deplete(user.getUserId())) {
                    AlertUtils.showInfo("Success", "User deleted successfully.");
                    loadUsers();
                } else {
                    AlertUtils.showError("Deletion Failed", "Failed to delete user.");
                }
            } catch (SQLException e) {
                AlertUtils.showDatabaseError("delete user", e);
            }
        }
    }

    @FXML
    private void handleBackToDashboard(ActionEvent event) {
        ViewNavigator.goToAdminDashboard();
    }
}
