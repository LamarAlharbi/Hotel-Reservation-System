package hotelreservationsystem.controllers;

import hotelreservationsystem.dao.RoomDAO;
import java.sql.SQLException;
import hotelreservationsystem.models.Guest;
import hotelreservationsystem.models.Room;
import hotelreservationsystem.utils.AlertUtils;
import hotelreservationsystem.utils.Session;
import hotelreservationsystem.utils.ViewNavigator;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.util.ArrayList;

public class BrowseRoomsController {

    @FXML
    private TableView<Room> roomsTable;

    @FXML
    private TableColumn<Room, String> roomNumberCol;

    @FXML
    private TableColumn<Room, String> roomTypeCol;

    @FXML
    private TableColumn<Room, Double> priceCol;

    @FXML
    private TableColumn<Room, Integer> capacityCol;

    @FXML
    private TableColumn<Room, String> amenitiesCol;

    @FXML
    private TableColumn<Room, String> statusCol;

    @FXML
    private TableColumn<Room, Void> actionCol;

    private RoomDAO roomDAO;
    private Guest currentGuest;
    private ObservableList<Room> allRooms;

    @FXML
    public void initialize() {
        roomDAO = new RoomDAO();
        if (Session.getInstance().isLoggedIn() && Session.getInstance().isGuest()) {
            currentGuest = (Guest) Session.getInstance().getCurrentUser();
        } else {
            AlertUtils.showError("Access Denied", "You must be logged in as a guest to access this page.");
            ViewNavigator.goToLogin();
            return;
        }

        setupTableColumns();
        loadAllRooms();
    }

    private void setupTableColumns() {
        roomNumberCol.setCellValueFactory(new PropertyValueFactory<>("roomNumber"));
        roomTypeCol.setCellValueFactory(new PropertyValueFactory<>("roomType"));
        priceCol.setCellValueFactory(new PropertyValueFactory<>("pricePerNight"));
        capacityCol.setCellValueFactory(new PropertyValueFactory<>("capacity"));
        amenitiesCol.setCellValueFactory(new PropertyValueFactory<>("amenities"));
        statusCol.setCellValueFactory(new PropertyValueFactory<>("status"));
        priceCol.setCellFactory(column -> new TableCell<Room, Double>() {
            @Override
            protected void updateItem(Double price, boolean empty) {
                super.updateItem(price, empty);
                if (empty || price == null) {
                    setText(null);
                } else {
                    setText(String.format("$%.2f", price));
                }
            }
        });
        actionCol.setCellFactory(column -> new TableCell<Room, Void>() {
            private final Button bookButton = new Button("Book Room");

            {
                bookButton.setStyle("-fx-background-color: #27ae60; -fx-text-fill: white;");
                bookButton.setOnAction(event -> {
                    Room room = getTableView().getItems().get(getIndex());
                    handleBookRoom(room);
                });
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) {
                    setGraphic(null);
                } else {
                    Room room = getTableView().getItems().get(getIndex());
                    if ("AVAILABLE".equals(room.getStatus())) {
                        setGraphic(bookButton);
                    } else {
                        setGraphic(null);
                    }
                }
            }
        });
    }

    private void loadAllRooms() {
        try {
            ArrayList<Room> rooms = roomDAO.findAll();
            allRooms = FXCollections.observableArrayList(rooms);
            roomsTable.setItems(allRooms);
        } catch (SQLException e) {
            AlertUtils.showDatabaseError("load rooms", e);
        }
    }

    private void handleBookRoom(Room room) {
        Session.getInstance().setAttribute("selectedRoom", room);
        ViewNavigator.goToMakeReservation();
    }

    @FXML
    private void handleBackToDashboard(ActionEvent event) {
        ViewNavigator.goToGuestDashboard();
    }
}
