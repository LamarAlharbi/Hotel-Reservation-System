package hotelreservationsystem.controllers;

import hotelreservationsystem.dao.ReservationDAO;
import hotelreservationsystem.dao.RoomDAO;
import java.sql.SQLException;
import hotelreservationsystem.models.Receptionist;
import hotelreservationsystem.models.Reservation;
import hotelreservationsystem.models.Room;
import hotelreservationsystem.utils.AlertUtils;
import hotelreservationsystem.utils.Session;
import hotelreservationsystem.utils.ViewNavigator;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;

import java.util.ArrayList;

public class ReceptionistDashboardController {

    @FXML
    private Label welcomeLabel;

    @FXML
    private Label todayArrivalsLabel;

    @FXML
    private Label todayDeparturesLabel;

    @FXML
    private Label pendingReservationsLabel;

    @FXML
    private Label availableRoomsLabel;

    @FXML
    private Button logoutButton;

    private ReservationDAO reservationDAO;
    private RoomDAO roomDAO;
    private Receptionist currentReceptionist;

    @FXML
    public void initialize() {
        reservationDAO = new ReservationDAO();
        roomDAO = new RoomDAO();

        if (Session.getInstance().isLoggedIn() && Session.getInstance().isReceptionist()) {
            currentReceptionist = (Receptionist) Session.getInstance().getCurrentUser();
            welcomeLabel.setText("Welcome, " + currentReceptionist.getFullName() + "!");
            loadStatistics();
        } else {
            AlertUtils.showError("Access Denied", "You must be logged in as a receptionist to access this page.");
            ViewNavigator.goToLogin();
        }
    }

    private void loadStatistics() {
        try {
            ArrayList<Reservation> todayArrivals = reservationDAO.findTodaysArrivals();
            todayArrivalsLabel.setText(String.valueOf(todayArrivals.size()));
            ArrayList<Reservation> todayDepartures = reservationDAO.findTodaysDepartures();
            todayDeparturesLabel.setText(String.valueOf(todayDepartures.size()));
            ArrayList<Reservation> pendingReservations = reservationDAO.findByStatus("PENDING");
            pendingReservationsLabel.setText(String.valueOf(pendingReservations.size()));
            ArrayList<Room> availableRooms = roomDAO.findAvailableRooms();
            availableRoomsLabel.setText(String.valueOf(availableRooms.size()));

        } catch (SQLException e) {
            AlertUtils.showDatabaseError("load dashboard statistics", e);
        }
    }

    @FXML
    private void handleManageReservations(ActionEvent event) {
        ViewNavigator.goToManageReservations();
    }

    @FXML
    private void handleRoomManagement(ActionEvent event) {
        ViewNavigator.goToRoomManagement();
    }

    @FXML
    private void handleLogout(ActionEvent event) {
        if (AlertUtils.showConfirmation("Logout", "Are you sure you want to logout?")) {
            Session.getInstance().logout();
            ViewNavigator.goToLogin();
        }
    }
}
