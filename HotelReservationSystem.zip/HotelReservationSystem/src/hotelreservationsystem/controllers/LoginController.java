package hotelreservationsystem.controllers;

import hotelreservationsystem.dao.UserDAO;
import hotelreservationsystem.models.User;

import java.sql.SQLException;
import hotelreservationsystem.utils.AlertUtils;
import hotelreservationsystem.utils.Session;
import hotelreservationsystem.utils.ValidationUtils;
import hotelreservationsystem.utils.ViewNavigator;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;

public class LoginController {

    @FXML
    private TextField usernameField;

    @FXML
    private PasswordField passwordField;

    @FXML
    private Button loginButton;

    @FXML
    private Hyperlink registerLink;

    private UserDAO userDAO;

    @FXML
    public void initialize() {
        userDAO = new UserDAO();

        passwordField.setOnAction(event -> handleLogin(null));
    }

    @FXML
    private void handleLogin(ActionEvent event) {
        String username = usernameField.getText();
        String password = passwordField.getText();

        if (!validateInput(username, password)) {
            return;
        }

        try {
            User user = userDAO.authenticate(username, password);

            if (user != null) {
                Session.getInstance().setCurrentUser(user);

                AlertUtils.showSuccess("Login Successful", "Welcome, " + user.getFullName() + "!");

                ViewNavigator.goToDashboardByRole(user.getRole());
            } else {
                AlertUtils.showAuthenticationError();
                passwordField.clear();
            }
        } catch (SQLException e) {
            AlertUtils.showDatabaseError("authenticate user", e);
        }
    }

    @FXML
    private void handleRegister(ActionEvent event) {
        ViewNavigator.goToRegistration();
    }

    private boolean validateInput(String username, String password) {
        if (ValidationUtils.isEmpty(username)) {
            AlertUtils.showValidationError("Please enter your username.");
            usernameField.requestFocus();
            return false;
        }

        if (ValidationUtils.isEmpty(password)) {
            AlertUtils.showValidationError("Please enter your password.");
            passwordField.requestFocus();
            return false;
        }

        return true;
    }
}
