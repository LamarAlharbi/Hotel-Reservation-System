package hotelreservationsystem.controllers;

import hotelreservationsystem.dao.RoomDAO;
import java.sql.SQLException;
import hotelreservationsystem.models.Receptionist;
import hotelreservationsystem.models.Room;
import hotelreservationsystem.utils.AlertUtils;
import hotelreservationsystem.utils.Session;
import hotelreservationsystem.utils.ViewNavigator;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;

import java.util.ArrayList;
import java.util.stream.Collectors;

public class RoomManagementController {

    @FXML
    private TableView<Room> roomsTable;

    @FXML
    private TableColumn<Room, String> roomNumberCol;

    @FXML
    private TableColumn<Room, String> roomTypeCol;

    @FXML
    private TableColumn<Room, Double> priceCol;

    @FXML
    private TableColumn<Room, Integer> capacityCol;

    @FXML
    private TableColumn<Room, String> amenitiesCol;

    @FXML
    private TableColumn<Room, String> statusCol;

    @FXML
    private TableColumn<Room, Void> actionCol;

    private RoomDAO roomDAO;
    private Receptionist currentReceptionist;
    private ObservableList<Room> allRooms;

    @FXML
    public void initialize() {
        roomDAO = new RoomDAO();

        if (Session.getInstance().isLoggedIn() && Session.getInstance().isReceptionist()) {
            currentReceptionist = (Receptionist) Session.getInstance().getCurrentUser();
        } else {
            AlertUtils.showError("Access Denied", "You must be logged in as a receptionist to access this page.");
            ViewNavigator.goToLogin();
            return;
        }

        setupTableColumns();
        loadRooms();
    }

    private void setupTableColumns() {
        roomNumberCol.setCellValueFactory(new PropertyValueFactory<>("roomNumber"));
        roomTypeCol.setCellValueFactory(new PropertyValueFactory<>("roomType"));
        priceCol.setCellValueFactory(new PropertyValueFactory<>("pricePerNight"));
        capacityCol.setCellValueFactory(new PropertyValueFactory<>("capacity"));
        amenitiesCol.setCellValueFactory(new PropertyValueFactory<>("amenities"));
        statusCol.setCellValueFactory(new PropertyValueFactory<>("status"));

        priceCol.setCellFactory(column -> new TableCell<Room, Double>() {
            @Override
            protected void updateItem(Double price, boolean empty) {
                super.updateItem(price, empty);
                if (empty || price == null) {
                    setText(null);
                } else {
                    setText(String.format("$%.2f", price));
                }
            }
        });

        actionCol.setCellFactory(column -> new TableCell<Room, Void>() {
            private final Button availableButton = new Button("Set Available");
            private final Button occupiedButton = new Button("Set Occupied");
            private final Button maintenanceButton = new Button("Maintenance");

            {
                availableButton.setStyle("-fx-background-color: #27ae60; -fx-text-fill: white; -fx-font-size: 10;");
                occupiedButton.setStyle("-fx-background-color: #e74c3c; -fx-text-fill: white; -fx-font-size: 10;");
                maintenanceButton.setStyle("-fx-background-color: #f39c12; -fx-text-fill: white; -fx-font-size: 10;");

                availableButton.setOnAction(event -> {
                    Room room = getTableView().getItems().get(getIndex());
                    updateRoomStatus(room, "AVAILABLE");
                });

                occupiedButton.setOnAction(event -> {
                    Room room = getTableView().getItems().get(getIndex());
                    updateRoomStatus(room, "OCCUPIED");
                });

                maintenanceButton.setOnAction(event -> {
                    Room room = getTableView().getItems().get(getIndex());
                    updateRoomStatus(room, "MAINTENANCE");
                });
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) {
                    setGraphic(null);
                } else {
                    Room room = getTableView().getItems().get(getIndex());
                    HBox buttons = new HBox(5);
                    buttons.setAlignment(Pos.CENTER);

                    String currentStatus = room.getStatus();

                    if (!"AVAILABLE".equals(currentStatus)) {
                        buttons.getChildren().add(availableButton);
                    }
                    if (!"OCCUPIED".equals(currentStatus)) {
                        buttons.getChildren().add(occupiedButton);
                    }
                    if (!"MAINTENANCE".equals(currentStatus)) {
                        buttons.getChildren().add(maintenanceButton);
                    }

                    setGraphic(buttons);
                }
            }
        });
    }

    private void loadRooms() {
        try {
            ArrayList<Room> rooms = roomDAO.findAll();
            allRooms = FXCollections.observableArrayList(rooms);
            roomsTable.setItems(allRooms);
        } catch (SQLException e) {
            AlertUtils.showDatabaseError("load rooms", e);
        }
    }

    @FXML
    private void handleRefresh(ActionEvent event) {
        loadRooms();
    }

    private void updateRoomStatus(Room room, String newStatus) {
        String message = String.format(
                "Change status of Room %s from '%s' to '%s'?",
                room.getRoomNumber(),
                room.getStatus(),
                newStatus
        );

        if (AlertUtils.showConfirmation("Update Room Status", message)) {
            try {
                room.setStatus(newStatus);
                if (roomDAO.update(room)) {
                    AlertUtils.showInfo("Success", "Room status updated successfully.");
                    loadRooms();
                } else {
                    AlertUtils.showError("Update Failed", "Failed to update room status. Please try again.");
                }
            } catch (SQLException e) {
                AlertUtils.showDatabaseError("update room status", e);
            }
        }
    }

    @FXML
    private void handleBackToDashboard(ActionEvent event) {
        ViewNavigator.goToReceptionistDashboard();
    }
}
