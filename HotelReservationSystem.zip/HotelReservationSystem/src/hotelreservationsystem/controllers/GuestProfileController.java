package hotelreservationsystem.controllers;

import hotelreservationsystem.dao.UserDAO;
import java.sql.SQLException;
import hotelreservationsystem.models.Guest;
import hotelreservationsystem.utils.AlertUtils;
import hotelreservationsystem.utils.Session;
import hotelreservationsystem.utils.ValidationUtils;
import hotelreservationsystem.utils.ViewNavigator;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;

public class GuestProfileController {

    @FXML
    private Label usernameLabel;

    @FXML
    private TextField fullNameField;

    @FXML
    private TextField emailField;

    @FXML
    private TextField phoneField;

    @FXML
    private TextArea addressArea;

    @FXML
    private Label memberSinceLabel;

    @FXML
    private PasswordField currentPasswordField;

    @FXML
    private PasswordField newPasswordField;

    @FXML
    private PasswordField confirmPasswordField;

    private UserDAO userDAO;
    private Guest currentGuest;

    @FXML
    public void initialize() {
        userDAO = new UserDAO();
        if (Session.getInstance().isLoggedIn() && Session.getInstance().isGuest()) {
            currentGuest = (Guest) Session.getInstance().getCurrentUser();
            loadProfileData();
        } else {
            AlertUtils.showError("Access Denied", "You must be logged in as a guest to access this page.");
            ViewNavigator.goToLogin();
        }
    }

    private void loadProfileData() {
        usernameLabel.setText(currentGuest.getUsername());
        fullNameField.setText(currentGuest.getFullName());
        emailField.setText(currentGuest.getEmail());
        phoneField.setText(currentGuest.getPhone());
        addressArea.setText(currentGuest.getAddress());
        memberSinceLabel.setText(currentGuest.getCreatedDate().toString());
    }

    @FXML
    private void handleUpdateProfile(ActionEvent event) {
        String fullName = fullNameField.getText().trim();
        String email = emailField.getText().trim();
        String phone = phoneField.getText().trim();
        String address = addressArea.getText().trim();

        if (fullName.isEmpty() || email.isEmpty() || phone.isEmpty()) {
            AlertUtils.showError("Validation Error", "Full Name, Email, and Phone are required fields.");
            return;
        }

        if (!ValidationUtils.isValidEmail(email)) {
            AlertUtils.showError("Invalid Email", "Please enter a valid email address.");
            return;
        }

        if (!ValidationUtils.isValidPhone(phone)) {
            AlertUtils.showError("Invalid Phone", "Please enter a valid phone number (10 digits).");
            return;
        }
        currentGuest.setFullName(fullName);
        currentGuest.setEmail(email);
        currentGuest.setPhone(phone);
        currentGuest.setAddress(address.isEmpty() ? null : address);

        try {
            if (userDAO.update(currentGuest)) {
                Session.getInstance().setCurrentUser(currentGuest);
                AlertUtils.showInfo("Success", "Profile updated successfully!");
            } else {
                AlertUtils.showError("Update Failed", "Failed to update profile. Please try again.");
            }
        } catch (SQLException e) {
            AlertUtils.showDatabaseError("update profile", e);
        }
    }

    @FXML
    private void handleChangePassword(ActionEvent event) {
        String currentPassword = currentPasswordField.getText();
        String newPassword = newPasswordField.getText();
        String confirmPassword = confirmPasswordField.getText();
        if (currentPassword.isEmpty() || newPassword.isEmpty() || confirmPassword.isEmpty()) {
            AlertUtils.showError("Validation Error", "All password fields are required.");
            return;
        }
        if (!currentPassword.equals(currentGuest.getPassword())) {
            AlertUtils.showError("Invalid Password", "Current password is incorrect.");
            return;
        }
        if (!ValidationUtils.isValidPassword(newPassword)) {
            AlertUtils.showError("Invalid Password", "New password must be at least 6 characters long.");
            return;
        }

        if (!newPassword.equals(confirmPassword)) {
            AlertUtils.showError("Password Mismatch", "New password and confirmation do not match.");
            return;
        }

        currentGuest.setPassword(newPassword);

        try {
            if (userDAO.update(currentGuest)) {
                Session.getInstance().setCurrentUser(currentGuest);
                currentPasswordField.clear();
                newPasswordField.clear();
                confirmPasswordField.clear();

                AlertUtils.showInfo("Success", "Password changed successfully!");
            } else {
                AlertUtils.showError("Update Failed", "Failed to change password. Please try again.");
            }
        } catch (SQLException e) {
            AlertUtils.showDatabaseError("change password", e);
        }
    }

    @FXML
    private void handleCancel(ActionEvent event) {
        if (AlertUtils.showConfirmation("Cancel", "Discard all changes and return to dashboard?")) {
            ViewNavigator.goToGuestDashboard();
        }
    }

    @FXML
    private void handleBackToDashboard(ActionEvent event) {
        ViewNavigator.goToGuestDashboard();
    }
}
