package hotelreservationsystem.controllers;

import hotelreservationsystem.dao.RoomDAO;
import java.sql.SQLException;
import hotelreservationsystem.models.Administrator;
import hotelreservationsystem.models.Room;
import hotelreservationsystem.utils.AlertUtils;
import hotelreservationsystem.utils.Session;
import hotelreservationsystem.utils.ViewNavigator;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;

import java.util.ArrayList;
import java.util.Optional;
import java.util.stream.Collectors;

public class RoomConfigurationController {

    @FXML
    private TableView<Room> roomsTable;

    @FXML
    private TableColumn<Room, Integer> roomIdCol;

    @FXML
    private TableColumn<Room, String> roomNumberCol;

    @FXML
    private TableColumn<Room, String> roomTypeCol;

    @FXML
    private TableColumn<Room, Double> priceCol;

    @FXML
    private TableColumn<Room, Integer> capacityCol;

    @FXML
    private TableColumn<Room, String> amenitiesCol;

    @FXML
    private TableColumn<Room, String> statusCol;

    @FXML
    private TableColumn<Room, Void> actionCol;

    private RoomDAO roomDAO;
    private Administrator currentAdmin;
    private ObservableList<Room> allRooms;

    @FXML
    public void initialize() {
        roomDAO = new RoomDAO();

        if (Session.getInstance().isLoggedIn() && Session.getInstance().isAdministrator()) {
            currentAdmin = (Administrator) Session.getInstance().getCurrentUser();
        } else {
            AlertUtils.showError("Access Denied", "You must be logged in as an administrator to access this page.");
            ViewNavigator.goToLogin();
            return;
        }

        setupTableColumns();

        loadRooms();
    }

    private void setupTableColumns() {
        roomIdCol.setCellValueFactory(new PropertyValueFactory<>("roomId"));
        roomNumberCol.setCellValueFactory(new PropertyValueFactory<>("roomNumber"));
        roomTypeCol.setCellValueFactory(new PropertyValueFactory<>("roomType"));
        priceCol.setCellValueFactory(new PropertyValueFactory<>("pricePerNight"));
        capacityCol.setCellValueFactory(new PropertyValueFactory<>("capacity"));
        amenitiesCol.setCellValueFactory(new PropertyValueFactory<>("amenities"));
        statusCol.setCellValueFactory(new PropertyValueFactory<>("status"));

        priceCol.setCellFactory(column -> new TableCell<Room, Double>() {
            @Override
            protected void updateItem(Double price, boolean empty) {
                super.updateItem(price, empty);
                if (empty || price == null) {
                    setText(null);
                } else {
                    setText(String.format("$%.2f", price));
                }
            }
        });

        actionCol.setCellFactory(column -> new TableCell<Room, Void>() {
            private final Button editButton = new Button("Edit");
            private final Button deleteButton = new Button("Delete");

            {
                editButton.setStyle("-fx-background-color: #3498db; -fx-text-fill: white; -fx-font-size: 10;");
                deleteButton.setStyle("-fx-background-color: #e74c3c; -fx-text-fill: white; -fx-font-size: 10;");

                editButton.setOnAction(event -> {
                    Room room = getTableView().getItems().get(getIndex());
                    handleEditRoom(room);
                });

                deleteButton.setOnAction(event -> {
                    Room room = getTableView().getItems().get(getIndex());
                    handleDeleteRoom(room);
                });
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) {
                    setGraphic(null);
                } else {
                    HBox buttons = new HBox(5);
                    buttons.setAlignment(Pos.CENTER);
                    buttons.getChildren().addAll(editButton, deleteButton);
                    setGraphic(buttons);
                }
            }
        });
    }

    private void loadRooms() {
        try {
            ArrayList<Room> rooms = roomDAO.findAll();
            allRooms = FXCollections.observableArrayList(rooms);
            roomsTable.setItems(allRooms);
        } catch (SQLException e) {
            AlertUtils.showDatabaseError("load rooms", e);
        }
    }

    @FXML
    private void handleRefresh(ActionEvent event) {
        loadRooms();
    }

    @FXML
    private void handleAddRoom(ActionEvent event) {
        Dialog<Room> dialog = new Dialog<>();
        dialog.setTitle("Add New Room");
        dialog.setHeaderText("Enter new room information");

        ButtonType saveButtonType = new ButtonType("Save", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(saveButtonType, ButtonType.CANCEL);

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20, 150, 10, 10));

        TextField roomNumberField = new TextField();
        ComboBox<String> roomTypeCombo = new ComboBox<>();
        roomTypeCombo.setItems(FXCollections.observableArrayList("Single", "Double", "Suite", "Deluxe"));
        roomTypeCombo.getSelectionModel().selectFirst();
        TextField priceField = new TextField();
        Spinner<Integer> capacitySpinner = new Spinner<>(1, 10, 2);
        TextField amenitiesField = new TextField();
        ComboBox<String> statusCombo = new ComboBox<>();
        statusCombo.setItems(FXCollections.observableArrayList("AVAILABLE", "OCCUPIED", "MAINTENANCE"));
        statusCombo.getSelectionModel().selectFirst();
        TextArea descriptionArea = new TextArea();
        descriptionArea.setPrefRowCount(3);

        grid.add(new Label("Room Number:"), 0, 0);
        grid.add(roomNumberField, 1, 0);
        grid.add(new Label("Room Type:"), 0, 1);
        grid.add(roomTypeCombo, 1, 1);
        grid.add(new Label("Price per Night:"), 0, 2);
        grid.add(priceField, 1, 2);
        grid.add(new Label("Capacity:"), 0, 3);
        grid.add(capacitySpinner, 1, 3);
        grid.add(new Label("Amenities:"), 0, 4);
        grid.add(amenitiesField, 1, 4);
        grid.add(new Label("Status:"), 0, 5);
        grid.add(statusCombo, 1, 5);
        grid.add(new Label("Description:"), 0, 6);
        grid.add(descriptionArea, 1, 6);

        dialog.getDialogPane().setContent(grid);

        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == saveButtonType) {
                try {
                    String roomNumberStr = roomNumberField.getText().trim();
                    int roomNumber = Integer.parseInt(roomNumberStr);
                    double price = Double.parseDouble(priceField.getText().trim());
                    String amenities = amenitiesField.getText().trim();
                    String description = descriptionArea.getText().trim();

                    if (roomNumber <= 0 || price <= 0) {
                        AlertUtils.showError("Invalid Input", "Room number and price must be positive numbers.");
                        return null;
                    }

                    if (amenities.isEmpty()) {
                        AlertUtils.showError("Validation Error", "Amenities are required.");
                        return null;
                    }

                    Room newRoom = new Room();
                    newRoom.setRoomNumber(roomNumberStr);
                    newRoom.setRoomType(roomTypeCombo.getValue());
                    newRoom.setPricePerNight(price);
                    newRoom.setCapacity(capacitySpinner.getValue());
                    newRoom.setAmenities(amenities);
                    newRoom.setStatus(statusCombo.getValue());
                    newRoom.setDescription(description.isEmpty() ? null : description);

                    return newRoom;
                } catch (NumberFormatException e) {
                    AlertUtils.showError("Invalid Input", "Please enter valid numbers for room number and price.");
                    return null;
                }
            }
            return null;
        });

        Optional<Room> result = dialog.showAndWait();
        result.ifPresent(room -> {
            try {
                Room created = roomDAO.create(room);
                if (created != null) {
                    AlertUtils.showInfo("Success", "Room created successfully!");
                    loadRooms();
                } else {
                    AlertUtils.showError("Creation Failed", "Failed to create room. Room number may already exist.");
                }
            } catch (SQLException e) {
                AlertUtils.showDatabaseError("create room", e);
            }
        });
    }

    private void handleEditRoom(Room room) {
        Dialog<Room> dialog = new Dialog<>();
        dialog.setTitle("Edit Room");
        dialog.setHeaderText("Edit room information");

        ButtonType saveButtonType = new ButtonType("Save", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(saveButtonType, ButtonType.CANCEL);

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20, 150, 10, 10));

        ComboBox<String> roomTypeCombo = new ComboBox<>();
        roomTypeCombo.setItems(FXCollections.observableArrayList("Single", "Double", "Suite", "Deluxe"));
        roomTypeCombo.setValue(room.getRoomType());
        TextField priceField = new TextField(String.valueOf(room.getPricePerNight()));
        Spinner<Integer> capacitySpinner = new Spinner<>(1, 10, room.getCapacity());
        TextField amenitiesField = new TextField(room.getAmenities());
        ComboBox<String> statusCombo = new ComboBox<>();
        statusCombo.setItems(FXCollections.observableArrayList("AVAILABLE", "OCCUPIED", "MAINTENANCE"));
        statusCombo.setValue(room.getStatus());
        TextArea descriptionArea = new TextArea(room.getDescription() != null ? room.getDescription() : "");
        descriptionArea.setPrefRowCount(3);

        grid.add(new Label("Room Number:"), 0, 0);
        grid.add(new Label(String.valueOf(room.getRoomNumber())), 1, 0);
        grid.add(new Label("Room Type:"), 0, 1);
        grid.add(roomTypeCombo, 1, 1);
        grid.add(new Label("Price per Night:"), 0, 2);
        grid.add(priceField, 1, 2);
        grid.add(new Label("Capacity:"), 0, 3);
        grid.add(capacitySpinner, 1, 3);
        grid.add(new Label("Amenities:"), 0, 4);
        grid.add(amenitiesField, 1, 4);
        grid.add(new Label("Status:"), 0, 5);
        grid.add(statusCombo, 1, 5);
        grid.add(new Label("Description:"), 0, 6);
        grid.add(descriptionArea, 1, 6);

        dialog.getDialogPane().setContent(grid);

        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == saveButtonType) {
                try {
                    double price = Double.parseDouble(priceField.getText().trim());
                    String amenities = amenitiesField.getText().trim();
                    String description = descriptionArea.getText().trim();

                    if (price <= 0) {
                        AlertUtils.showError("Invalid Input", "Price must be a positive number.");
                        return null;
                    }

                    if (amenities.isEmpty()) {
                        AlertUtils.showError("Validation Error", "Amenities are required.");
                        return null;
                    }

                    room.setRoomType(roomTypeCombo.getValue());
                    room.setPricePerNight(price);
                    room.setCapacity(capacitySpinner.getValue());
                    room.setAmenities(amenities);
                    room.setStatus(statusCombo.getValue());
                    room.setDescription(description.isEmpty() ? null : description);

                    return room;
                } catch (NumberFormatException e) {
                    AlertUtils.showError("Invalid Input", "Please enter a valid number for price.");
                    return null;
                }
            }
            return null;
        });

        Optional<Room> result = dialog.showAndWait();
        result.ifPresent(updatedRoom -> {
            try {
                if (roomDAO.update(updatedRoom)) {
                    AlertUtils.showInfo("Success", "Room updated successfully!");
                    loadRooms();
                } else {
                    AlertUtils.showError("Update Failed", "Failed to update room.");
                }
            } catch (SQLException e) {
                AlertUtils.showDatabaseError("update room", e);
            }
        });
    }

    private void handleDeleteRoom(Room room) {
        String message = String.format("Are you sure you want to delete Room #%d?", room.getRoomNumber());
        if (AlertUtils.showConfirmation("Delete Room", message)) {
            try {
                if (roomDAO.deplete(room.getRoomId())) {
                    AlertUtils.showInfo("Success", "Room deleted successfully.");
                    loadRooms();
                } else {
                    AlertUtils.showError("Deletion Failed", "Failed to delete room. There may be reservations associated with this room.");
                }
            } catch (SQLException e) {
                AlertUtils.showDatabaseError("delete room", e);
            }
        }
    }

    @FXML
    private void handleBackToDashboard(ActionEvent event) {
        ViewNavigator.goToAdminDashboard();
    }
}
