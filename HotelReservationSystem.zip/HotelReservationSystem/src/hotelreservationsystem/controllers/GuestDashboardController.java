package hotelreservationsystem.controllers;

import hotelreservationsystem.dao.ReservationDAO;
import java.sql.SQLException;
import hotelreservationsystem.models.Guest;
import hotelreservationsystem.models.Reservation;
import hotelreservationsystem.utils.AlertUtils;
import hotelreservationsystem.utils.Session;
import hotelreservationsystem.utils.ViewNavigator;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;

import java.util.ArrayList;

public class GuestDashboardController {

    @FXML
    private Label welcomeLabel;

    @FXML
    private Label activeReservationsLabel;

    @FXML
    private Label pastReservationsLabel;

    @FXML
    private Button browseRoomsBtn;

    @FXML
    private Button myReservationsBtn;

    @FXML
    private Button bookingHistoryBtn;

    @FXML
    private Button profileBtn;

    @FXML
    private Button logoutButton;

    private ReservationDAO reservationDAO;
    private Guest currentGuest;

    @FXML
    public void initialize() {
        reservationDAO = new ReservationDAO();
        if (Session.getInstance().isLoggedIn() && Session.getInstance().isGuest()) {
            currentGuest = (Guest) Session.getInstance().getCurrentUser();
            welcomeLabel.setText("Welcome, " + currentGuest.getFullName() + "!");
            loadStatistics();
        } else {
            AlertUtils.showError("Access Denied", "You must be logged in as a guest to access this page.");
            ViewNavigator.goToLogin();
        }
    }

    private void loadStatistics() {
        try {
            ArrayList<Reservation> activeReservations = reservationDAO.findActiveReservationsByGuestId(currentGuest.getUserId());
            activeReservationsLabel.setText(String.valueOf(activeReservations.size()));
            ArrayList<Reservation> pastReservations = reservationDAO.findPastReservationsByGuestId(currentGuest.getUserId());
            pastReservationsLabel.setText(String.valueOf(pastReservations.size()));

        } catch (SQLException e) {
            AlertUtils.showDatabaseError("load reservation statistics", e);
        }
    }

    @FXML
    private void handleBrowseRooms(ActionEvent event) {
        ViewNavigator.goToBrowseRooms();
    }

    @FXML
    private void handleMyReservations(ActionEvent event) {
        ViewNavigator.goToMyReservations();
    }

    @FXML
    private void handleBookingHistory(ActionEvent event) {
        ViewNavigator.goToBookingHistory();
    }

    @FXML
    private void handleProfile(ActionEvent event) {
        ViewNavigator.goToGuestProfile();
    }

    @FXML
    private void handleLogout(ActionEvent event) {
        if (AlertUtils.showConfirmation("Logout", "Are you sure you want to logout?")) {
            Session.getInstance().logout();
            ViewNavigator.goToLogin();
        }
    }
}
