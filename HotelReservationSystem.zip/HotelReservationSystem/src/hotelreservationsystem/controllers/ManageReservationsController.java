package hotelreservationsystem.controllers;

import hotelreservationsystem.dao.ReservationDAO;
import java.sql.SQLException;
import hotelreservationsystem.models.Receptionist;
import hotelreservationsystem.models.Reservation;
import hotelreservationsystem.utils.AlertUtils;
import hotelreservationsystem.utils.Session;
import hotelreservationsystem.utils.ViewNavigator;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.stream.Collectors;

public class ManageReservationsController {

    @FXML
    private TableView<Reservation> reservationsTable;

    @FXML
    private TableColumn<Reservation, Integer> reservationIdCol;

    @FXML
    private TableColumn<Reservation, String> guestNameCol;

    @FXML
    private TableColumn<Reservation, String> roomNumberCol;

    @FXML
    private TableColumn<Reservation, String> roomTypeCol;

    @FXML
    private TableColumn<Reservation, LocalDate> checkInCol;

    @FXML
    private TableColumn<Reservation, LocalDate> checkOutCol;

    @FXML
    private TableColumn<Reservation, String> statusCol;

    @FXML
    private TableColumn<Reservation, Double> totalPriceCol;

    @FXML
    private TableColumn<Reservation, Void> actionCol;

    private ReservationDAO reservationDAO;
    private Receptionist currentReceptionist;
    private ObservableList<Reservation> allReservations;

    @FXML
    public void initialize() {
        reservationDAO = new ReservationDAO();

        if (Session.getInstance().isLoggedIn() && Session.getInstance().isReceptionist()) {
            currentReceptionist = (Receptionist) Session.getInstance().getCurrentUser();
        } else {
            AlertUtils.showError("Access Denied", "You must be logged in as a receptionist to access this page.");
            ViewNavigator.goToLogin();
            return;
        }

        setupTableColumns();

        loadReservations();
    }

    private void setupTableColumns() {
        reservationIdCol.setCellValueFactory(new PropertyValueFactory<>("reservationId"));
        checkInCol.setCellValueFactory(new PropertyValueFactory<>("checkInDate"));
        checkOutCol.setCellValueFactory(new PropertyValueFactory<>("checkOutDate"));
        statusCol.setCellValueFactory(new PropertyValueFactory<>("status"));
        totalPriceCol.setCellValueFactory(new PropertyValueFactory<>("totalPrice"));

        guestNameCol.setCellValueFactory(cellData -> {
            Reservation reservation = cellData.getValue();
            String guestName = (reservation.getGuest() != null) ? reservation.getGuest().getFullName() : "N/A";
            return new javafx.beans.property.SimpleStringProperty(guestName);
        });
        roomNumberCol.setCellValueFactory(cellData -> {
            Reservation reservation = cellData.getValue();
            String roomNum = (reservation.getRoom() != null) ? reservation.getRoom().getRoomNumber() : "N/A";
            return new javafx.beans.property.SimpleStringProperty(roomNum);
        });
        roomTypeCol.setCellValueFactory(cellData -> {
            Reservation reservation = cellData.getValue();
            String roomType = (reservation.getRoom() != null) ? reservation.getRoom().getRoomType() : "N/A";
            return new javafx.beans.property.SimpleStringProperty(roomType);
        });

        totalPriceCol.setCellFactory(column -> new TableCell<Reservation, Double>() {
            @Override
            protected void updateItem(Double price, boolean empty) {
                super.updateItem(price, empty);
                if (empty || price == null) {
                    setText(null);
                } else {
                    setText(String.format("$%.2f", price));
                }
            }
        });

        actionCol.setCellFactory(column -> new TableCell<Reservation, Void>() {
            private final Button checkInButton = new Button("Check-In");
            private final Button checkOutButton = new Button("Check-Out");
            private final Button viewButton = new Button("View");

            {
                checkInButton.setStyle("-fx-background-color: #27ae60; -fx-text-fill: white; -fx-font-size: 10;");
                checkOutButton.setStyle("-fx-background-color: #e74c3c; -fx-text-fill: white; -fx-font-size: 10;");
                viewButton.setStyle("-fx-background-color: #3498db; -fx-text-fill: white; -fx-font-size: 10;");

                checkInButton.setOnAction(event -> {
                    Reservation reservation = getTableView().getItems().get(getIndex());
                    handleCheckIn(reservation);
                });

                checkOutButton.setOnAction(event -> {
                    Reservation reservation = getTableView().getItems().get(getIndex());
                    handleCheckOut(reservation);
                });

                viewButton.setOnAction(event -> {
                    Reservation reservation = getTableView().getItems().get(getIndex());
                    handleViewReservation(reservation);
                });
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) {
                    setGraphic(null);
                } else {
                    Reservation reservation = getTableView().getItems().get(getIndex());
                    HBox buttons = new HBox(5);
                    buttons.setAlignment(Pos.CENTER);

                    if ("CONFIRMED".equals(reservation.getStatus())) {
                        buttons.getChildren().add(checkInButton);
                    }
                    if ("CHECKED_IN".equals(reservation.getStatus())) {
                        buttons.getChildren().add(checkOutButton);
                    }

                    buttons.getChildren().add(viewButton);
                    setGraphic(buttons);
                }
            }
        });
    }

    private void loadReservations() {
        try {
            ArrayList<Reservation> reservations = reservationDAO.findAll();
            allReservations = FXCollections.observableArrayList(reservations);
            reservationsTable.setItems(allReservations);
        } catch (SQLException e) {
            AlertUtils.showDatabaseError("load reservations", e);
        }
    }

    @FXML
    private void handleRefresh(ActionEvent event) {
        loadReservations();
    }

    private void handleCheckIn(Reservation reservation) {
        if (AlertUtils.showConfirmation("Check-In", "Check-in guest for reservation ID " + reservation.getReservationId() + "?")) {
            try {
                reservation.setStatus("CHECKED_IN");
                if (reservationDAO.update(reservation)) {
                    AlertUtils.showInfo("Success", "Guest checked in successfully.");
                    loadReservations();
                } else {
                    AlertUtils.showError("Check-In Failed", "Failed to check in guest. Please try again.");
                }
            } catch (SQLException e) {
                AlertUtils.showDatabaseError("check in guest", e);
            }
        }
    }

    private void handleCheckOut(Reservation reservation) {
        if (AlertUtils.showConfirmation("Check-Out", "Check-out guest for reservation ID " + reservation.getReservationId() + "?")) {
            try {
                reservation.setStatus("CHECKED_OUT");
                if (reservationDAO.update(reservation)) {
                    AlertUtils.showInfo("Success", "Guest checked out successfully.");
                    loadReservations();
                } else {
                    AlertUtils.showError("Check-Out Failed", "Failed to check out guest. Please try again.");
                }
            } catch (SQLException e) {
                AlertUtils.showDatabaseError("check out guest", e);
            }
        }
    }

    private void handleViewReservation(Reservation reservation) {
        String guestName = (reservation.getGuest() != null) ? reservation.getGuest().getFullName() : "N/A";
        String roomNumber = (reservation.getRoom() != null) ? reservation.getRoom().getRoomNumber() : "N/A";
        String roomType = (reservation.getRoom() != null) ? reservation.getRoom().getRoomType() : "N/A";

        String details = String.format(
                "Reservation Details\n\n"
                + "Reservation ID: %d\n"
                + "Guest: %s\n"
                + "Room: %s (%s)\n"
                + "Check-In: %s\n"
                + "Check-Out: %s\n"
                + "Booked On: %s\n"
                + "Status: %s\n"
                + "Total Price: $%.2f\n"
                + "Notes: %s",
                reservation.getReservationId(),
                guestName,
                roomNumber,
                roomType,
                reservation.getCheckInDate().toString(),
                reservation.getCheckOutDate().toString(),
                reservation.getReservationDate().toString(),
                reservation.getStatus(),
                reservation.getTotalPrice(),
                (reservation.getNotes() != null && !reservation.getNotes().isEmpty()) ? reservation.getNotes() : "None"
        );

        AlertUtils.showInfo("Reservation Details", details);
    }

    @FXML
    private void handleBackToDashboard(ActionEvent event) {
        ViewNavigator.goToReceptionistDashboard();
    }
}
