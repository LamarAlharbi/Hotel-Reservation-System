package hotelreservationsystem.dao;

import hotelreservationsystem.database.DatabaseConnection;
import hotelreservationsystem.models.*;

import java.sql.*;
import java.util.ArrayList;

public class UserDAO implements GenericDAO<User> {

    private Connection connection;

    public UserDAO() {
        try {
            this.connection = DatabaseConnection.getInstance().getConnection();
        } catch (SQLException e) {
            System.err.println("Failed to get database connection in UserDAO");
            e.printStackTrace();
        }
    }

    @Override
    public User create(User user) throws SQLException {
        String sql = "INSERT INTO USERS (USER_ID, USERNAME, PASSWORD, FULL_NAME, EMAIL, PHONE, ADDRESS, ROLE) "
                + "VALUES (USER_SEQ.NEXTVAL, ?, ?, ?, ?, ?, ?, ?)";

        try (PreparedStatement pstmt = connection.prepareStatement(sql, new String[]{"USER_ID"})) {
            pstmt.setString(1, user.getUsername());
            pstmt.setString(2, user.getPassword());
            pstmt.setString(3, user.getFullName());
            pstmt.setString(4, user.getEmail());
            pstmt.setString(5, user.getPhone());
            pstmt.setString(6, user.getAddress());
            pstmt.setString(7, user.getRole());

            int affectedRows = pstmt.executeUpdate();

            if (affectedRows > 0) {
                ResultSet rs = pstmt.getGeneratedKeys();
                if (rs.next()) {
                    user.setUserId(rs.getInt(1));
                }
                return user;
            } else {
                throw new SQLException("Creating user failed, no rows affected.");
            }
        } catch (SQLException e) {
            throw new SQLException("Error creating user: " + e.getMessage(), e);
        }
    }

    @Override
    public User findById(int id) throws SQLException {
        String sql = "SELECT * FROM USERS WHERE USER_ID = ?";

        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                return createUserFromResultSet(rs);
            }
            return null;
        } catch (SQLException e) {
            throw new SQLException("Error finding user by ID: " + e.getMessage(), e);
        }
    }

    @Override
    public ArrayList<User> findAll() throws SQLException {
        String sql = "SELECT * FROM USERS ORDER BY USER_ID";
        ArrayList<User> users = new ArrayList<>();

        try (Statement stmt = connection.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                users.add(createUserFromResultSet(rs));
            }
            return users;
        } catch (SQLException e) {
            throw new SQLException("Error finding all users: " + e.getMessage(), e);
        }
    }

    @Override
    public boolean update(User user) throws SQLException {
        String sql = "UPDATE USERS SET USERNAME = ?, PASSWORD = ?, FULL_NAME = ?, "
                + "EMAIL = ?, PHONE = ?, ADDRESS = ?, ROLE = ? WHERE USER_ID = ?";

        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, user.getUsername());
            pstmt.setString(2, user.getPassword());
            pstmt.setString(3, user.getFullName());
            pstmt.setString(4, user.getEmail());
            pstmt.setString(5, user.getPhone());
            pstmt.setString(6, user.getAddress());
            pstmt.setString(7, user.getRole());
            pstmt.setInt(8, user.getUserId());

            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new SQLException("Error updating user: " + e.getMessage(), e);
        }
    }

    @Override
    public boolean deplete(int id) throws SQLException {
        String sql = "DELETE FROM USERS WHERE USER_ID = ?";

        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new SQLException("Error deleting user: " + e.getMessage(), e);
        }
    }

    public User findByUsername(String username) throws SQLException {
        String sql = "SELECT * FROM USERS WHERE USERNAME = ?";

        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, username);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                return createUserFromResultSet(rs);
            }
            return null;
        } catch (SQLException e) {
            throw new SQLException("Error finding user by username: " + e.getMessage(), e);
        }
    }

    public User findByEmail(String email) throws SQLException {
        String sql = "SELECT * FROM USERS WHERE EMAIL = ?";

        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, email);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                return createUserFromResultSet(rs);
            }
            return null;
        } catch (SQLException e) {
            throw new SQLException("Error finding user by email: " + e.getMessage(), e);
        }
    }

    public ArrayList<User> findByRole(String role) throws SQLException {
        String sql = "SELECT * FROM USERS WHERE ROLE = ? ORDER BY FULL_NAME";
        ArrayList<User> users = new ArrayList<>();

        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, role);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                users.add(createUserFromResultSet(rs));
            }
            return users;
        } catch (SQLException e) {
            throw new SQLException("Error finding users by role: " + e.getMessage(), e);
        }
    }

    public User authenticate(String username, String password) throws SQLException {
        String sql = "SELECT * FROM USERS WHERE USERNAME = ? AND PASSWORD = ?";

        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, username);
            pstmt.setString(2, password);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                return createUserFromResultSet(rs);
            }
            return null;
        } catch (SQLException e) {
            throw new SQLException("Error authenticating user: " + e.getMessage(), e);
        }
    }

    public boolean usernameExists(String username) throws SQLException {
        String sql = "SELECT COUNT(*) FROM USERS WHERE USERNAME = ?";

        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, username);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
            return false;
        } catch (SQLException e) {
            throw new SQLException("Error checking username existence: " + e.getMessage(), e);
        }
    }

    public boolean emailExists(String email) throws SQLException {
        String sql = "SELECT COUNT(*) FROM USERS WHERE EMAIL = ?";

        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, email);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
            return false;
        } catch (SQLException e) {
            throw new SQLException("Error checking email existence: " + e.getMessage(), e);
        }
    }

    private User createUserFromResultSet(ResultSet rs) throws SQLException {
        int userId = rs.getInt("USER_ID");
        String username = rs.getString("USERNAME");
        String password = rs.getString("PASSWORD");
        String fullName = rs.getString("FULL_NAME");
        String email = rs.getString("EMAIL");
        String phone = rs.getString("PHONE");
        String address = rs.getString("ADDRESS");
        String role = rs.getString("ROLE");
        Date createdDate = rs.getDate("CREATED_DATE");

        User user;

        switch (role) {
            case "GUEST":
                user = new Guest(userId, username, password, fullName, email, phone, address);
                break;
            case "RECEPTIONIST":
                user = new Receptionist(userId, username, password, fullName, email, phone, address);
                break;
            case "ADMINISTRATOR":
                user = new Administrator(userId, username, password, fullName, email, phone, address);
                break;
            default:
                user = new User(userId, username, password, fullName, email, phone, address, role);
                break;
        }

        user.setCreatedDate(createdDate);
        return user;
    }
}
