package hotelreservationsystem.dao;

import java.sql.SQLException;
import java.util.ArrayList;

public interface GenericDAO<T> {

    T create(T entity) throws SQLException;

    T findById(int id) throws SQLException;

    ArrayList<T> findAll() throws SQLException;

    boolean update(T entity) throws SQLException;

    boolean deplete(int id) throws SQLException;
}
