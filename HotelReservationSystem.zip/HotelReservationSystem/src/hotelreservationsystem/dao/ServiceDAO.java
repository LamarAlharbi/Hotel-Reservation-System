package hotelreservationsystem.dao;

import hotelreservationsystem.database.DatabaseConnection;
import hotelreservationsystem.models.Service;

import java.sql.*;
import java.util.ArrayList;

public class ServiceDAO implements GenericDAO<Service> {

    private Connection connection;

    public ServiceDAO() {
        try {
            this.connection = DatabaseConnection.getInstance().getConnection();
        } catch (SQLException e) {
            System.err.println("Failed to get database connection in ServiceDAO");
            e.printStackTrace();
        }
    }

    @Override
    public Service create(Service service) throws SQLException {
        String sql = "INSERT INTO SERVICES (SERVICE_ID, SERVICE_NAME, DESCRIPTION, PRICE) "
                + "VALUES (SERVICE_SEQ.NEXTVAL, ?, ?, ?)";

        try (PreparedStatement pstmt = connection.prepareStatement(sql, new String[]{"SERVICE_ID"})) {
            pstmt.setString(1, service.getServiceName());
            pstmt.setString(2, service.getDescription());
            pstmt.setDouble(3, service.getPrice());

            int affectedRows = pstmt.executeUpdate();

            if (affectedRows > 0) {
                ResultSet rs = pstmt.getGeneratedKeys();
                if (rs.next()) {
                    service.setServiceId(rs.getInt(1));
                }
                return service;
            } else {
                throw new SQLException("Creating service failed, no rows affected.");
            }
        } catch (SQLException e) {
            throw new SQLException("Error creating service: " + e.getMessage(), e);
        }
    }

    @Override
    public Service findById(int id) throws SQLException {
        String sql = "SELECT * FROM SERVICES WHERE SERVICE_ID = ?";

        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                return createServiceFromResultSet(rs);
            }
            return null;
        } catch (SQLException e) {
            throw new SQLException("Error finding service by ID: " + e.getMessage(), e);
        }
    }

    @Override
    public ArrayList<Service> findAll() throws SQLException {
        String sql = "SELECT * FROM SERVICES ORDER BY SERVICE_NAME";
        ArrayList<Service> services = new ArrayList<>();

        try (Statement stmt = connection.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                services.add(createServiceFromResultSet(rs));
            }
            return services;
        } catch (SQLException e) {
            throw new SQLException("Error finding all services: " + e.getMessage(), e);
        }
    }

    @Override
    public boolean update(Service service) throws SQLException {
        String sql = "UPDATE SERVICES SET SERVICE_NAME = ?, DESCRIPTION = ?, PRICE = ? WHERE SERVICE_ID = ?";

        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, service.getServiceName());
            pstmt.setString(2, service.getDescription());
            pstmt.setDouble(3, service.getPrice());
            pstmt.setInt(4, service.getServiceId());

            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new SQLException("Error updating service: " + e.getMessage(), e);
        }
    }

    @Override
    public boolean deplete(int id) throws SQLException {
        String sql = "DELETE FROM SERVICES WHERE SERVICE_ID = ?";

        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new SQLException("Error deleting service: " + e.getMessage(), e);
        }
    }

    public Service findByName(String serviceName) throws SQLException {
        String sql = "SELECT * FROM SERVICES WHERE SERVICE_NAME = ?";

        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, serviceName);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                return createServiceFromResultSet(rs);
            }
            return null;
        } catch (SQLException e) {
            throw new SQLException("Error finding service by name: " + e.getMessage(), e);
        }
    }

    public ArrayList<Service> findByReservationId(int reservationId) throws SQLException {
        String sql = "SELECT s.* FROM SERVICES s "
                + "JOIN RESERVATION_SERVICES rs ON s.SERVICE_ID = rs.SERVICE_ID "
                + "WHERE rs.RESERVATION_ID = ?";
        ArrayList<Service> services = new ArrayList<>();

        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, reservationId);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                services.add(createServiceFromResultSet(rs));
            }
            return services;
        } catch (SQLException e) {
            throw new SQLException("Error finding services for reservation: " + e.getMessage(), e);
        }
    }

    public boolean addServiceToReservation(int reservationId, int serviceId, int quantity) throws SQLException {
        String sql = "INSERT INTO RESERVATION_SERVICES (RESERVATION_SERVICE_ID, RESERVATION_ID, SERVICE_ID, QUANTITY) "
                + "VALUES (RES_SERVICE_SEQ.NEXTVAL, ?, ?, ?)";

        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, reservationId);
            pstmt.setInt(2, serviceId);
            pstmt.setInt(3, quantity);

            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new SQLException("Error adding service to reservation: " + e.getMessage(), e);
        }
    }

    public boolean removeServiceFromReservation(int reservationId, int serviceId) throws SQLException {
        String sql = "DELETE FROM RESERVATION_SERVICES WHERE RESERVATION_ID = ? AND SERVICE_ID = ?";

        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, reservationId);
            pstmt.setInt(2, serviceId);

            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new SQLException("Error removing service from reservation: " + e.getMessage(), e);
        }
    }

    private Service createServiceFromResultSet(ResultSet rs) throws SQLException {
        return new Service(
                rs.getInt("SERVICE_ID"),
                rs.getString("SERVICE_NAME"),
                rs.getString("DESCRIPTION"),
                rs.getDouble("PRICE")
        );
    }
}
