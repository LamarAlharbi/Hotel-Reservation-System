package hotelreservationsystem.dao;

import hotelreservationsystem.database.DatabaseConnection;
import hotelreservationsystem.models.Reservation;

import java.sql.*;
import java.util.ArrayList;
import java.util.Date;

public class ReservationDAO implements GenericDAO<Reservation> {

    private Connection connection;

    public ReservationDAO() {
        try {
            this.connection = DatabaseConnection.getInstance().getConnection();
        } catch (SQLException e) {
            System.err.println("Failed to get database connection in ReservationDAO");
            e.printStackTrace();
        }
    }

    @Override
    public Reservation create(Reservation reservation) throws SQLException {
        String sql = "INSERT INTO RESERVATIONS (RESERVATION_ID, GUEST_ID, ROOM_ID, CHECK_IN_DATE, CHECK_OUT_DATE, "
                + "RESERVATION_DATE, STATUS, TOTAL_PRICE, NOTES) "
                + "VALUES (RESERVATION_SEQ.NEXTVAL, ?, ?, ?, ?, SYSDATE, ?, ?, ?)";

        try (PreparedStatement pstmt = connection.prepareStatement(sql, new String[]{"RESERVATION_ID"})) {
            pstmt.setInt(1, reservation.getGuestId());
            pstmt.setInt(2, reservation.getRoomId());
            pstmt.setDate(3, new java.sql.Date(reservation.getCheckInDate().getTime()));
            pstmt.setDate(4, new java.sql.Date(reservation.getCheckOutDate().getTime()));
            pstmt.setString(5, reservation.getStatus());
            pstmt.setDouble(6, reservation.getTotalPrice());
            pstmt.setString(7, reservation.getNotes());

            int affectedRows = pstmt.executeUpdate();

            if (affectedRows > 0) {
                ResultSet rs = pstmt.getGeneratedKeys();
                if (rs.next()) {
                    reservation.setReservationId(rs.getInt(1));
                }
                return reservation;
            } else {
                throw new SQLException("Creating reservation failed, no rows affected.");
            }
        } catch (SQLException e) {
            throw new SQLException("Error creating reservation: " + e.getMessage(), e);
        }
    }

    @Override
    public Reservation findById(int id) throws SQLException {
        String sql = "SELECT * FROM RESERVATIONS WHERE RESERVATION_ID = ?";

        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                return createReservationFromResultSet(rs);
            }
            return null;
        } catch (SQLException e) {
            throw new SQLException("Error finding reservation by ID: " + e.getMessage(), e);
        }
    }

    @Override
    public ArrayList<Reservation> findAll() throws SQLException {
        String sql = "SELECT * FROM RESERVATIONS ORDER BY RESERVATION_DATE DESC";
        ArrayList<Reservation> reservations = new ArrayList<>();

        try (Statement stmt = connection.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                reservations.add(createReservationFromResultSet(rs));
            }
            return reservations;
        } catch (SQLException e) {
            throw new SQLException("Error finding all reservations: " + e.getMessage(), e);
        }
    }

    @Override
    public boolean update(Reservation reservation) throws SQLException {
        String sql = "UPDATE RESERVATIONS SET GUEST_ID = ?, ROOM_ID = ?, CHECK_IN_DATE = ?, "
                + "CHECK_OUT_DATE = ?, STATUS = ?, TOTAL_PRICE = ?, NOTES = ? WHERE RESERVATION_ID = ?";

        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, reservation.getGuestId());
            pstmt.setInt(2, reservation.getRoomId());
            pstmt.setDate(3, new java.sql.Date(reservation.getCheckInDate().getTime()));
            pstmt.setDate(4, new java.sql.Date(reservation.getCheckOutDate().getTime()));
            pstmt.setString(5, reservation.getStatus());
            pstmt.setDouble(6, reservation.getTotalPrice());
            pstmt.setString(7, reservation.getNotes());
            pstmt.setInt(8, reservation.getReservationId());

            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new SQLException("Error updating reservation: " + e.getMessage(), e);
        }
    }

    @Override
    public boolean deplete(int id) throws SQLException {
        String sql = "DELETE FROM RESERVATIONS WHERE RESERVATION_ID = ?";

        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new SQLException("Error deleting reservation: " + e.getMessage(), e);
        }
    }

    public ArrayList<Reservation> findByGuestId(int guestId) throws SQLException {
        String sql = "SELECT * FROM RESERVATIONS WHERE GUEST_ID = ? ORDER BY CHECK_IN_DATE DESC";
        ArrayList<Reservation> reservations = new ArrayList<>();

        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, guestId);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                reservations.add(createReservationFromResultSet(rs));
            }
            return reservations;
        } catch (SQLException e) {
            throw new SQLException("Error finding reservations by guest ID: " + e.getMessage(), e);
        }
    }

    public ArrayList<Reservation> findByRoomId(int roomId) throws SQLException {
        String sql = "SELECT * FROM RESERVATIONS WHERE ROOM_ID = ? ORDER BY CHECK_IN_DATE DESC";
        ArrayList<Reservation> reservations = new ArrayList<>();

        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, roomId);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                reservations.add(createReservationFromResultSet(rs));
            }
            return reservations;
        } catch (SQLException e) {
            throw new SQLException("Error finding reservations by room ID: " + e.getMessage(), e);
        }
    }

    public ArrayList<Reservation> findByStatus(String status) throws SQLException {
        String sql = "SELECT * FROM RESERVATIONS WHERE STATUS = ? ORDER BY CHECK_IN_DATE";
        ArrayList<Reservation> reservations = new ArrayList<>();

        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, status);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                reservations.add(createReservationFromResultSet(rs));
            }
            return reservations;
        } catch (SQLException e) {
            throw new SQLException("Error finding reservations by status: " + e.getMessage(), e);
        }
    }

    public ArrayList<Reservation> findActiveReservationsByGuestId(int guestId) throws SQLException {
        String sql = "SELECT * FROM RESERVATIONS WHERE GUEST_ID = ? "
                + "AND STATUS NOT IN ('CANCELLED', 'CHECKED_OUT') ORDER BY CHECK_IN_DATE";
        ArrayList<Reservation> reservations = new ArrayList<>();

        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, guestId);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                reservations.add(createReservationFromResultSet(rs));
            }
            return reservations;
        } catch (SQLException e) {
            throw new SQLException("Error finding active reservations: " + e.getMessage(), e);
        }
    }

    public ArrayList<Reservation> findPastReservationsByGuestId(int guestId) throws SQLException {
        String sql = "SELECT * FROM RESERVATIONS WHERE GUEST_ID = ? "
                + "AND STATUS = 'CHECKED_OUT' ORDER BY CHECK_OUT_DATE DESC";
        ArrayList<Reservation> reservations = new ArrayList<>();

        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, guestId);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                reservations.add(createReservationFromResultSet(rs));
            }
            return reservations;
        } catch (SQLException e) {
            throw new SQLException("Error finding past reservations: " + e.getMessage(), e);
        }
    }

    public ArrayList<Reservation> findTodaysArrivals() throws SQLException {
        String sql = "SELECT * FROM RESERVATIONS WHERE TRUNC(CHECK_IN_DATE) = TRUNC(SYSDATE) "
                + "AND STATUS IN ('CONFIRMED', 'PENDING') ORDER BY CHECK_IN_DATE";
        ArrayList<Reservation> reservations = new ArrayList<>();

        try (Statement stmt = connection.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                reservations.add(createReservationFromResultSet(rs));
            }
            return reservations;
        } catch (SQLException e) {
            throw new SQLException("Error finding today's arrivals: " + e.getMessage(), e);
        }
    }

    public ArrayList<Reservation> findTodaysDepartures() throws SQLException {
        String sql = "SELECT * FROM RESERVATIONS WHERE TRUNC(CHECK_OUT_DATE) = TRUNC(SYSDATE) "
                + "AND STATUS = 'CHECKED_IN' ORDER BY CHECK_OUT_DATE";
        ArrayList<Reservation> reservations = new ArrayList<>();

        try (Statement stmt = connection.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                reservations.add(createReservationFromResultSet(rs));
            }
            return reservations;
        } catch (SQLException e) {
            throw new SQLException("Error finding today's departures: " + e.getMessage(), e);
        }
    }

    public boolean updateStatus(int reservationId, String status) throws SQLException {
        String sql = "UPDATE RESERVATIONS SET STATUS = ? WHERE RESERVATION_ID = ?";

        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, status);
            pstmt.setInt(2, reservationId);
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new SQLException("Error updating reservation status: " + e.getMessage(), e);
        }
    }

    public boolean isRoomAvailableForDateRange(int roomId, Date checkIn, Date checkOut) throws SQLException {
        String sql = "SELECT COUNT(*) FROM RESERVATIONS "
                + "WHERE ROOM_ID = ? AND STATUS IN ('CONFIRMED', 'CHECKED_IN') "
                + "AND ((CHECK_IN_DATE <= ? AND CHECK_OUT_DATE >= ?) "
                + "  OR (CHECK_IN_DATE <= ? AND CHECK_OUT_DATE >= ?) "
                + "  OR (CHECK_IN_DATE >= ? AND CHECK_OUT_DATE <= ?))";

        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            java.sql.Date sqlCheckIn = new java.sql.Date(checkIn.getTime());
            java.sql.Date sqlCheckOut = new java.sql.Date(checkOut.getTime());

            pstmt.setInt(1, roomId);
            pstmt.setDate(2, sqlCheckIn);
            pstmt.setDate(3, sqlCheckIn);
            pstmt.setDate(4, sqlCheckOut);
            pstmt.setDate(5, sqlCheckOut);
            pstmt.setDate(6, sqlCheckIn);
            pstmt.setDate(7, sqlCheckOut);

            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getInt(1) == 0; // Available if count is 0
            }
            return false;
        } catch (SQLException e) {
            throw new SQLException("Error checking room availability: " + e.getMessage(), e);
        }
    }

    public double getTotalRevenue() throws SQLException {
        String sql = "SELECT SUM(TOTAL_PRICE) FROM RESERVATIONS WHERE STATUS = 'CHECKED_OUT'";

        try (Statement stmt = connection.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {

            if (rs.next()) {
                return rs.getDouble(1);
            }
            return 0.0;
        } catch (SQLException e) {
            throw new SQLException("Error calculating total revenue: " + e.getMessage(), e);
        }
    }

    public double getRevenueForDateRange(Date startDate, Date endDate) throws SQLException {
        String sql = "SELECT SUM(TOTAL_PRICE) FROM RESERVATIONS "
                + "WHERE STATUS = 'CHECKED_OUT' "
                + "AND CHECK_OUT_DATE BETWEEN ? AND ?";

        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setDate(1, new java.sql.Date(startDate.getTime()));
            pstmt.setDate(2, new java.sql.Date(endDate.getTime()));
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                return rs.getDouble(1);
            }
            return 0.0;
        } catch (SQLException e) {
            throw new SQLException("Error calculating revenue for date range: " + e.getMessage(), e);
        }
    }

    private Reservation createReservationFromResultSet(ResultSet rs) throws SQLException {
        Reservation reservation = new Reservation();
        reservation.setReservationId(rs.getInt("RESERVATION_ID"));
        reservation.setGuestId(rs.getInt("GUEST_ID"));
        reservation.setRoomId(rs.getInt("ROOM_ID"));
        reservation.setCheckInDate(rs.getDate("CHECK_IN_DATE"));
        reservation.setCheckOutDate(rs.getDate("CHECK_OUT_DATE"));
        reservation.setReservationDate(rs.getDate("RESERVATION_DATE"));
        reservation.setStatus(rs.getString("STATUS"));
        reservation.setTotalPrice(rs.getDouble("TOTAL_PRICE"));
        reservation.setNotes(rs.getString("NOTES"));

        try {
            hotelreservationsystem.dao.UserDAO userDAO = new hotelreservationsystem.dao.UserDAO();
            hotelreservationsystem.dao.RoomDAO roomDAO = new hotelreservationsystem.dao.RoomDAO();

            hotelreservationsystem.models.User user = userDAO.findById(rs.getInt("GUEST_ID"));
            if (user instanceof hotelreservationsystem.models.Guest) {
                reservation.setGuest((hotelreservationsystem.models.Guest) user);
            }

            hotelreservationsystem.models.Room room = roomDAO.findById(rs.getInt("ROOM_ID"));
            reservation.setRoom(room);
        } catch (java.sql.SQLException e) {
            System.err.println("Warning: Could not load associated Guest/Room objects: " + e.getMessage());
        }

        return reservation;
    }
}
