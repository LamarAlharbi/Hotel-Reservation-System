package hotelreservationsystem.dao;

import hotelreservationsystem.database.DatabaseConnection;
import hotelreservationsystem.models.Room;

import java.sql.*;
import java.util.ArrayList;
import java.util.Date;

public class RoomDAO implements GenericDAO<Room> {

    private Connection connection;

    public RoomDAO() {
        try {
            this.connection = DatabaseConnection.getInstance().getConnection();
        } catch (SQLException e) {
            System.err.println("Failed to get database connection in RoomDAO");
            e.printStackTrace();
        }
    }

    @Override
    public Room create(Room room) throws SQLException {
        String sql = "INSERT INTO ROOMS (ROOM_ID, ROOM_NUMBER, ROOM_TYPE, PRICE_PER_NIGHT, CAPACITY, AMENITIES, STATUS, DESCRIPTION) "
                + "VALUES (ROOM_SEQ.NEXTVAL, ?, ?, ?, ?, ?, ?, ?)";

        try (PreparedStatement pstmt = connection.prepareStatement(sql, new String[]{"ROOM_ID"})) {
            pstmt.setString(1, room.getRoomNumber());
            pstmt.setString(2, room.getRoomType());
            pstmt.setDouble(3, room.getPricePerNight());
            pstmt.setInt(4, room.getCapacity());
            pstmt.setString(5, room.getAmenities());
            pstmt.setString(6, room.getStatus());
            pstmt.setString(7, room.getDescription());

            int affectedRows = pstmt.executeUpdate();

            if (affectedRows > 0) {
                ResultSet rs = pstmt.getGeneratedKeys();
                if (rs.next()) {
                    room.setRoomId(rs.getInt(1));
                }
                return room;
            } else {
                throw new SQLException("Creating room failed, no rows affected.");
            }
        } catch (SQLException e) {
            throw new SQLException("Error creating room: " + e.getMessage(), e);
        }
    }

    @Override
    public Room findById(int id) throws SQLException {
        String sql = "SELECT * FROM ROOMS WHERE ROOM_ID = ?";

        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                return createRoomFromResultSet(rs);
            }
            return null;
        } catch (SQLException e) {
            throw new SQLException("Error finding room by ID: " + e.getMessage(), e);
        }
    }

    @Override
    public ArrayList<Room> findAll() throws SQLException {
        String sql = "SELECT * FROM ROOMS ORDER BY ROOM_NUMBER";
        ArrayList<Room> rooms = new ArrayList<>();

        try (Statement stmt = connection.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                rooms.add(createRoomFromResultSet(rs));
            }
            return rooms;
        } catch (SQLException e) {
            throw new SQLException("Error finding all rooms: " + e.getMessage(), e);
        }
    }

    @Override
    public boolean update(Room room) throws SQLException {
        String sql = "UPDATE ROOMS SET ROOM_NUMBER = ?, ROOM_TYPE = ?, PRICE_PER_NIGHT = ?, "
                + "CAPACITY = ?, AMENITIES = ?, STATUS = ?, DESCRIPTION = ? WHERE ROOM_ID = ?";

        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, room.getRoomNumber());
            pstmt.setString(2, room.getRoomType());
            pstmt.setDouble(3, room.getPricePerNight());
            pstmt.setInt(4, room.getCapacity());
            pstmt.setString(5, room.getAmenities());
            pstmt.setString(6, room.getStatus());
            pstmt.setString(7, room.getDescription());
            pstmt.setInt(8, room.getRoomId());

            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new SQLException("Error updating room: " + e.getMessage(), e);
        }
    }

    @Override
    public boolean deplete(int id) throws SQLException {
        String sql = "DELETE FROM ROOMS WHERE ROOM_ID = ?";

        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new SQLException("Error deleting room: " + e.getMessage(), e);
        }
    }

    public Room findByRoomNumber(String roomNumber) throws SQLException {
        String sql = "SELECT * FROM ROOMS WHERE ROOM_NUMBER = ?";

        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, roomNumber);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                return createRoomFromResultSet(rs);
            }
            return null;
        } catch (SQLException e) {
            throw new SQLException("Error finding room by number: " + e.getMessage(), e);
        }
    }

    public ArrayList<Room> findByStatus(String status) throws SQLException {
        String sql = "SELECT * FROM ROOMS WHERE STATUS = ? ORDER BY ROOM_NUMBER";
        ArrayList<Room> rooms = new ArrayList<>();

        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, status);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                rooms.add(createRoomFromResultSet(rs));
            }
            return rooms;
        } catch (SQLException e) {
            throw new SQLException("Error finding rooms by status: " + e.getMessage(), e);
        }
    }

    public ArrayList<Room> findByType(String roomType) throws SQLException {
        String sql = "SELECT * FROM ROOMS WHERE ROOM_TYPE = ? ORDER BY ROOM_NUMBER";
        ArrayList<Room> rooms = new ArrayList<>();

        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, roomType);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                rooms.add(createRoomFromResultSet(rs));
            }
            return rooms;
        } catch (SQLException e) {
            throw new SQLException("Error finding rooms by type: " + e.getMessage(), e);
        }
    }

    public ArrayList<Room> findAvailableRooms() throws SQLException {
        return findByStatus("AVAILABLE");
    }

    public ArrayList<Room> findAvailableRoomsForDateRange(Date checkIn, Date checkOut) throws SQLException {
        String sql = "SELECT * FROM ROOMS WHERE STATUS = 'AVAILABLE' "
                + "AND ROOM_ID NOT IN ("
                + "  SELECT ROOM_ID FROM RESERVATIONS "
                + "  WHERE STATUS IN ('CONFIRMED', 'CHECKED_IN') "
                + "  AND ((CHECK_IN_DATE <= ? AND CHECK_OUT_DATE >= ?) "
                + "    OR (CHECK_IN_DATE <= ? AND CHECK_OUT_DATE >= ?) "
                + "    OR (CHECK_IN_DATE >= ? AND CHECK_OUT_DATE <= ?))"
                + ") ORDER BY ROOM_NUMBER";

        ArrayList<Room> rooms = new ArrayList<>();

        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            java.sql.Date sqlCheckIn = new java.sql.Date(checkIn.getTime());
            java.sql.Date sqlCheckOut = new java.sql.Date(checkOut.getTime());

            pstmt.setDate(1, sqlCheckIn);
            pstmt.setDate(2, sqlCheckIn);
            pstmt.setDate(3, sqlCheckOut);
            pstmt.setDate(4, sqlCheckOut);
            pstmt.setDate(5, sqlCheckIn);
            pstmt.setDate(6, sqlCheckOut);

            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                rooms.add(createRoomFromResultSet(rs));
            }
            return rooms;
        } catch (SQLException e) {
            throw new SQLException("Error finding available rooms for date range: " + e.getMessage(), e);
        }
    }

    public ArrayList<Room> findByPriceRange(double minPrice, double maxPrice) throws SQLException {
        String sql = "SELECT * FROM ROOMS WHERE PRICE_PER_NIGHT BETWEEN ? AND ? ORDER BY PRICE_PER_NIGHT";
        ArrayList<Room> rooms = new ArrayList<>();

        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setDouble(1, minPrice);
            pstmt.setDouble(2, maxPrice);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                rooms.add(createRoomFromResultSet(rs));
            }
            return rooms;
        } catch (SQLException e) {
            throw new SQLException("Error finding rooms by price range: " + e.getMessage(), e);
        }
    }

    public boolean updateStatus(int roomId, String status) throws SQLException {
        String sql = "UPDATE ROOMS SET STATUS = ? WHERE ROOM_ID = ?";

        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, status);
            pstmt.setInt(2, roomId);
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new SQLException("Error updating room status: " + e.getMessage(), e);
        }
    }

    private Room createRoomFromResultSet(ResultSet rs) throws SQLException {
        return new Room(
                rs.getInt("ROOM_ID"),
                rs.getString("ROOM_NUMBER"),
                rs.getString("ROOM_TYPE"),
                rs.getDouble("PRICE_PER_NIGHT"),
                rs.getInt("CAPACITY"),
                rs.getString("AMENITIES"),
                rs.getString("STATUS"),
                rs.getString("DESCRIPTION")
        );
    }
}
