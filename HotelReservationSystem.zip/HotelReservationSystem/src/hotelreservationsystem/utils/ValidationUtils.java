package hotelreservationsystem.utils;

import java.util.Date;
import java.util.regex.Pattern;


public class ValidationUtils {

    private static final Pattern EMAIL_PATTERN = Pattern.compile(
        "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$"
    );

    private static final Pattern PHONE_PATTERN = Pattern.compile(
        "^[+]?[(]?[0-9]{1,4}[)]?[-\\s\\.]?[(]?[0-9]{1,4}[)]?[-\\s\\.]?[0-9]{1,9}$"
    );

  
    public static boolean isEmpty(String str) {
        return str == null || str.trim().isEmpty();
    }

 
    public static boolean isNotEmpty(String str) {
        return !isEmpty(str);
    }

    public static boolean isValidEmail(String email) {
        if (isEmpty(email)) {
            return false;
        }
        return EMAIL_PATTERN.matcher(email).matches();
    }

   
    public static boolean isValidPhone(String phone) {
        if (isEmpty(phone)) {
            return false;
        }
        return PHONE_PATTERN.matcher(phone).matches();
    }

    public static boolean isValidPassword(String password) {
        return password != null && password.length() >= 6;
    }

    public static boolean passwordsMatch(String password, String confirmPassword) {
        return password != null && password.equals(confirmPassword);
    }

    public static boolean isValidUsername(String username) {
        if (isEmpty(username) || username.length() < 3) {
            return false;
        }
        return username.matches("^[a-zA-Z0-9._]+$");
    }


    public static boolean isPositiveNumber(double number) {
        return number > 0;
    }


    public static boolean isNonNegativeNumber(double number) {
        return number >= 0;
    }

    public static boolean isPositiveInteger(int number) {
        return number > 0;
    }


    public static boolean isValidDateRange(Date startDate, Date endDate) {
        if (startDate == null || endDate == null) {
            return false;
        }
        return startDate.before(endDate);
    }

 
    public static boolean isNotPastDate(Date date) {
        if (date == null) {
            return false;
        }
        Date today = new Date();
        Date dateOnly = new Date(date.getYear(), date.getMonth(), date.getDate());
        Date todayOnly = new Date(today.getYear(), today.getMonth(), today.getDate());
        return !dateOnly.before(todayOnly);
    }

 
    public static boolean isTodayOrFuture(Date date) {
        return isNotPastDate(date);
    }

   
    public static boolean isRequired(String value, String fieldName) {
        if (isEmpty(value)) {
            return false;
        }
        return true;
    }

 
    public static boolean isValidLength(String str, int minLength, int maxLength) {
        if (str == null) {
            return false;
        }
        int length = str.length();
        return length >= minLength && length <= maxLength;
    }


    public static boolean isNumeric(String str) {
        if (isEmpty(str)) {
            return false;
        }
        try {
            Double.parseDouble(str);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

 
    public static boolean isInteger(String str) {
        if (isEmpty(str)) {
            return false;
        }
        try {
            Integer.parseInt(str);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }


    public static String getRequiredFieldMessage(String fieldName) {
        return fieldName + " is required and cannot be empty.";
    }


    public static String getInvalidEmailMessage() {
        return "Please enter a valid email address.";
    }

 
    public static String getInvalidPhoneMessage() {
        return "Please enter a valid phone number.";
    }

   
    public static String getWeakPasswordMessage() {
        return "Password must be at least 6 characters long.";
    }

 
    public static String getPasswordMismatchMessage() {
        return "Passwords do not match. Please try again.";
    }

    public static String getInvalidUsernameMessage() {
        return "Username must be at least 3 characters and contain only letters, numbers, dots, and underscores.";
    }

    
    public static String getInvalidDateRangeMessage() {
        return "Check-in date must be before check-out date.";
    }

    public static String getPastDateMessage() {
        return "Date cannot be in the past.";
    }
}
