package hotelreservationsystem.utils;

import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import java.util.Optional;

public class AlertUtils {

    public static void showInfo(String title, String header, String content) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(header);
        alert.setContentText(content);
        alert.showAndWait();
    }


    public static void showInfo(String title, String message) {
        showInfo(title, "Information", message);
    }

    public static void showSuccess(String title, String message) {
        showInfo(title, "Success", message);
    }

    public static void showError(String title, String header, String content) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(header);
        alert.setContentText(content);
        alert.showAndWait();
    }

 
    public static void showError(String title, String message) {
        showError(title, "Error", message);
    }

    
    public static void showWarning(String title, String header, String content) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle(title);
        alert.setHeaderText(header);
        alert.setContentText(content);
        alert.showAndWait();
    }

 
    public static void showWarning(String title, String message) {
        showWarning(title, "Warning", message);
    }

  
    public static boolean showConfirmation(String title, String header, String content) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle(title);
        alert.setHeaderText(header);
        alert.setContentText(content);

        Optional<ButtonType> result = alert.showAndWait();
        return result.isPresent() && result.get() == ButtonType.OK;
    }

  
    public static boolean showConfirmation(String title, String message) {
        return showConfirmation(title, "Confirmation", message);
    }

    public static void showDatabaseError(String operation, Exception e) {
        showError(
            "Database Error",
            "Failed to " + operation,
            "Error: " + e.getMessage()
        );
    }

  
    public static void showValidationError(String message) {
        showError("Validation Error", "Invalid Input", message);
    }

    
    public static void showAuthenticationError() {
        showError(
            "Authentication Failed",
            "Login Error",
            "Invalid username or password. Please try again."
        );
    }


    public static void showAccessDenied() {
        showError(
            "Access Denied",
            "Unauthorized",
            "You do not have permission to perform this action."
        );
    }
}
