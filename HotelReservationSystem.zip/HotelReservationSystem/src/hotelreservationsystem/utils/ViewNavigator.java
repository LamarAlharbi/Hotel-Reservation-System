package hotelreservationsystem.utils;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;


public class ViewNavigator {

    private static Stage primaryStage;

    public static void setPrimaryStage(Stage stage) {
        primaryStage = stage;
    }


    public static void loadView(String fxmlPath) {
        try {
            String resourcePath = fxmlPath.startsWith("/") ? fxmlPath.substring(1) : fxmlPath;

            ClassLoader classLoader = ViewNavigator.class.getClassLoader();
            java.net.URL resourceUrl = classLoader.getResource(resourcePath);

            if (resourceUrl == null) {
                System.err.println("FXML resource not found: " + fxmlPath + " (searched for: " + resourcePath + ")");
                throw new java.io.FileNotFoundException("FXML resource not found: " + fxmlPath);
            }

            FXMLLoader loader = new FXMLLoader(resourceUrl);
            Parent root = loader.load();

            Scene scene = new Scene(root);
            primaryStage.setScene(scene);
            primaryStage.show();
        } catch (Exception e) {
            System.err.println("Error loading view: " + fxmlPath);
            e.printStackTrace();
            AlertUtils.showError("Navigation Error", "Failed to load view: " + fxmlPath);
        }
    }


    public static void loadView(String fxmlPath, String title) {
        primaryStage.setTitle(title);
        loadView(fxmlPath);
    }

    public static void loadView(String fxmlPath, String title, int width, int height) {
        try {
            String resourcePath = fxmlPath.startsWith("/") ? fxmlPath.substring(1) : fxmlPath;

            ClassLoader classLoader = ViewNavigator.class.getClassLoader();
            java.net.URL resourceUrl = classLoader.getResource(resourcePath);

            if (resourceUrl == null) {
                System.err.println("FXML resource not found: " + fxmlPath + " (searched for: " + resourcePath + ")");
                throw new java.io.FileNotFoundException("FXML resource not found: " + fxmlPath);
            }

            FXMLLoader loader = new FXMLLoader(resourceUrl);
            Parent root = loader.load();

            Scene scene = new Scene(root, width, height);
            primaryStage.setTitle(title);
            primaryStage.setScene(scene);
            primaryStage.show();
        } catch (Exception e) {
            System.err.println("Error loading view: " + fxmlPath);
            e.printStackTrace();
            AlertUtils.showError("Navigation Error", "Failed to load view: " + fxmlPath);
        }
    }

  
    public static void goToLogin() {
        loadView("/hotelreservationsystem/views/LoginView.fxml", "Hotel Reservation System - Login");
    }

 
    public static void goToRegistration() {
        loadView("/hotelreservationsystem/views/RegistrationView.fxml", "Hotel Reservation System - Register");
    }

  
    public static void goToGuestDashboard() {
        loadView("/hotelreservationsystem/views/GuestDashboardView.fxml", "Hotel Reservation System - Guest Dashboard", 1000, 700);
    }


    public static void goToReceptionistDashboard() {
        loadView("/hotelreservationsystem/views/ReceptionistDashboardView.fxml", "Hotel Reservation System - Receptionist Dashboard", 1000, 700);
    }

    public static void goToAdminDashboard() {
        loadView("/hotelreservationsystem/views/AdminDashboardView.fxml", "Hotel Reservation System - Admin Dashboard", 1000, 700);
    }


    public static void goToDashboardByRole(String role) {
        switch (role) {
            case "GUEST":
                goToGuestDashboard();
                break;
            case "RECEPTIONIST":
                goToReceptionistDashboard();
                break;
            case "ADMINISTRATOR":
                goToAdminDashboard();
                break;
            default:
                AlertUtils.showError("Navigation Error", "Unknown user role: " + role);
                goToLogin();
                break;
        }
    }

    public static void goToBrowseRooms() {
        loadView("/hotelreservationsystem/views/BrowseRoomsView.fxml", "Hotel Reservation System - Browse Rooms", 900, 700);
    }


    public static void goToMakeReservation() {
        loadView("/hotelreservationsystem/views/MakeReservationView.fxml", "Hotel Reservation System - Make Reservation", 750, 750);
    }


    public static void goToMyReservations() {
        loadView("/hotelreservationsystem/views/MyReservationsView.fxml", "Hotel Reservation System - My Reservations", 1000, 700);
    }

    public static void goToBookingHistory() {
        loadView("/hotelreservationsystem/views/BookingHistoryView.fxml", "Hotel Reservation System - Booking History", 1000, 700);
    }

    public static void goToGuestProfile() {
        loadView("/hotelreservationsystem/views/GuestProfileView.fxml", "Hotel Reservation System - My Profile", 700, 600);
    }

    public static void goToManageReservations() {
        loadView("/hotelreservationsystem/views/ManageReservationsView.fxml", "Hotel Reservation System - Manage Reservations", 1100, 700);
    }

    public static void goToRoomManagement() {
        loadView("/hotelreservationsystem/views/RoomManagementView.fxml", "Hotel Reservation System - Room Management", 1000, 700);
    }

    public static void goToUserManagement() {
        loadView("/hotelreservationsystem/views/UserManagementView.fxml", "Hotel Reservation System - User Management", 1100, 700);
    }

    public static void goToRoomConfiguration() {
        loadView("/hotelreservationsystem/views/RoomConfigurationView.fxml", "Hotel Reservation System - Room Configuration", 1000, 700);
    }

    public static void goToServicesConfiguration() {
        loadView("/hotelreservationsystem/views/ServicesConfigurationView.fxml", "Hotel Reservation System - Services Configuration", 900, 700);
    }

    public static void goToReports() {
        loadView("/hotelreservationsystem/views/ReportsView.fxml", "Hotel Reservation System - Reports", 1000, 700);
    }
}
