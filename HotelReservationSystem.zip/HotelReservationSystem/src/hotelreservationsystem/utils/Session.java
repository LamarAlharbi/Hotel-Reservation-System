package hotelreservationsystem.utils;

import hotelreservationsystem.models.User;
import java.util.HashMap;

public class Session {

    private static Session instance;
    private User currentUser;
    private HashMap<String, Object> attributes;

    private Session() {
        this.attributes = new HashMap<>();
    }


    public static Session getInstance() {
        if (instance == null) {
            instance = new Session();
        }
        return instance;
    }

   
    public void setCurrentUser(User user) {
        this.currentUser = user;
    }

  
    public User getCurrentUser() {
        return currentUser;
    }

   
    public boolean isLoggedIn() {
        return currentUser != null;
    }

 
    public int getCurrentUserId() {
        return (currentUser != null) ? currentUser.getUserId() : -1;
    }

 
    public String getCurrentUserRole() {
        return (currentUser != null) ? currentUser.getRole() : null;
    }

    public boolean hasRole(String role) {
        return currentUser != null && currentUser.hasRole(role);
    }

  
    public boolean isGuest() {
        return hasRole("GUEST");
    }


    public boolean isReceptionist() {
        return hasRole("RECEPTIONIST");
    }

   
    public boolean isAdministrator() {
        return hasRole("ADMINISTRATOR");
    }

   
    public void setAttribute(String key, Object value) {
        attributes.put(key, value);
    }

   
    public Object getAttribute(String key) {
        return attributes.get(key);
    }

 
    public void removeAttribute(String key) {
        attributes.remove(key);
    }

    public void logout() {
        this.currentUser = null;
        this.attributes.clear();
    }

   
    public void clear() {
        logout();
    }
}
