package hotelreservationsystem.models;


public class Room {

    private int roomId;
    private String roomNumber;
    private String roomType;
    private double pricePerNight;
    private int capacity;
    private String amenities;
    private String status; 
    private String description;

    public Room() {
        this.status = "AVAILABLE";
    }

    public Room(int roomId, String roomNumber, String roomType, double pricePerNight,
                int capacity, String amenities, String status, String description) {
        this.roomId = roomId;
        this.roomNumber = roomNumber;
        this.roomType = roomType;
        this.pricePerNight = pricePerNight;
        this.capacity = capacity;
        this.amenities = amenities;
        this.status = status;
        this.description = description;
    }

    public Room(String roomNumber, String roomType, double pricePerNight,
                int capacity, String amenities, String status, String description) {
        this.roomNumber = roomNumber;
        this.roomType = roomType;
        this.pricePerNight = pricePerNight;
        this.capacity = capacity;
        this.amenities = amenities;
        this.status = status;
        this.description = description;
    }
    public int getRoomId() {
        return roomId;
    }

    public void setRoomId(int roomId) {
        this.roomId = roomId;
    }

    public String getRoomNumber() {
        return roomNumber;
    }

    public void setRoomNumber(String roomNumber) {
        this.roomNumber = roomNumber;
    }

    public String getRoomType() {
        return roomType;
    }

    public void setRoomType(String roomType) {
        this.roomType = roomType;
    }

    public double getPricePerNight() {
        return pricePerNight;
    }

    public void setPricePerNight(double pricePerNight) {
        this.pricePerNight = pricePerNight;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public String getAmenities() {
        return amenities;
    }

    public void setAmenities(String amenities) {
        this.amenities = amenities;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public boolean isAvailable() {
        return "AVAILABLE".equals(status);
    }

    public boolean isOccupied() {
        return "OCCUPIED".equals(status);
    }

    public boolean isUnderMaintenance() {
        return "MAINTENANCE".equals(status);
    }

    public void markAsAvailable() {
        this.status = "AVAILABLE";
    }

    public void markAsOccupied() {
        this.status = "OCCUPIED";
    }

    public void markAsUnderMaintenance() {
        this.status = "MAINTENANCE";
    }

    public double calculateTotalPrice(int numberOfNights) {
        return pricePerNight * numberOfNights;
    }

    public boolean isValid() {
        return roomNumber != null && !roomNumber.trim().isEmpty() &&
               roomType != null && !roomType.trim().isEmpty() &&
               pricePerNight > 0 &&
               capacity > 0 &&
               status != null && !status.trim().isEmpty();
    }

    @Override
    public String toString() {
        return "Room{" +
                "roomId=" + roomId +
                ", roomNumber='" + roomNumber + '\'' +
                ", roomType='" + roomType + '\'' +
                ", pricePerNight=" + pricePerNight +
                ", capacity=" + capacity +
                ", status='" + status + '\'' +
                '}';
    }
}
