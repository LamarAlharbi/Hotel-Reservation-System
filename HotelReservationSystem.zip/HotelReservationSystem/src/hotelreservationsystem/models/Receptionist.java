package hotelreservationsystem.models;


public class Receptionist extends User {

    private String employeeId;
    private String shift; 
    public Receptionist() {
        super();
        super.setRole("RECEPTIONIST");
    }
    public Receptionist(int userId, String username, String password, String fullName,
                       String email, String phone, String address) {
        super(userId, username, password, fullName, email, phone, address, "RECEPTIONIST");
    }
    public Receptionist(String username, String password, String fullName,
                       String email, String phone, String address) {
        super(username, password, fullName, email, phone, address, "RECEPTIONIST");
    }
    public Receptionist(String username, String password, String fullName,
                       String email, String phone, String address,
                       String employeeId, String shift) {
        super(username, password, fullName, email, phone, address, "RECEPTIONIST");
        this.employeeId = employeeId;
        this.shift = shift;
    }
    public String getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(String employeeId) {
        this.employeeId = employeeId;
    }

    public String getShift() {
        return shift;
    }

    public void setShift(String shift) {
        this.shift = shift;
    }

    public boolean canManageReservations() {
        return true;
    }

    public boolean canCheckInGuests() {
        return true;
    }

    public boolean canCheckOutGuests() {
        return true;
    }

    @Override
    public String toString() {
        return "Receptionist{" +
                "userId=" + getUserId() +
                ", username='" + getUsername() + '\'' +
                ", fullName='" + getFullName() + '\'' +
                ", email='" + getEmail() + '\'' +
                ", employeeId='" + employeeId + '\'' +
                ", shift='" + shift + '\'' +
                '}';
    }
}
