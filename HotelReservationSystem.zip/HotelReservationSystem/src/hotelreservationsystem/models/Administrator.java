package hotelreservationsystem.models;

public class Administrator extends User {

    private String adminLevel; 
    public Administrator() {
        super();
        super.setRole("ADMINISTRATOR");
        this.adminLevel = "MANAGER";
    }
    public Administrator(int userId, String username, String password, String fullName,
                        String email, String phone, String address) {
        super(userId, username, password, fullName, email, phone, address, "ADMINISTRATOR");
        this.adminLevel = "MANAGER";
    }
    public Administrator(String username, String password, String fullName,
                        String email, String phone, String address) {
        super(username, password, fullName, email, phone, address, "ADMINISTRATOR");
        this.adminLevel = "MANAGER";
    }
    public Administrator(String username, String password, String fullName,
                        String email, String phone, String address, String adminLevel) {
        super(username, password, fullName, email, phone, address, "ADMINISTRATOR");
        this.adminLevel = adminLevel;
    }
    public String getAdminLevel() {
        return adminLevel;
    }

    public void setAdminLevel(String adminLevel) {
        this.adminLevel = adminLevel;
    }

    public boolean canManageUsers() {
        return true;
    }

    public boolean canManageRooms() {
        return true;
    }

    public boolean canManageServices() {
        return true;
    }

    public boolean canGenerateReports() {
        return true;
    }

    public boolean canConfigureSystem() {
        return true;
    }

    public boolean canViewAllReservations() {
        return true;
    }
    public boolean isSuperAdmin() {
        return "SUPER_ADMIN".equals(adminLevel);
    }

    @Override
    public String toString() {
        return "Administrator{" +
                "userId=" + getUserId() +
                ", username='" + getUsername() + '\'' +
                ", fullName='" + getFullName() + '\'' +
                ", email='" + getEmail() + '\'' +
                ", adminLevel='" + adminLevel + '\'' +
                '}';
    }
}
