package hotelreservationsystem.models;

import java.util.Date;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

public class Reservation {

    private int reservationId;
    private int guestId;
    private int roomId;
    private Date checkInDate;
    private Date checkOutDate;
    private Date reservationDate;
    private String status; 
    private double totalPrice;
    private String notes;

    private Guest guest;
    private Room room;
    private ArrayList<Service> services;

    public Reservation() {
        this.reservationDate = new Date();
        this.status = "PENDING";
        this.services = new ArrayList<>();
    }

    public Reservation(int reservationId, int guestId, int roomId,
                      Date checkInDate, Date checkOutDate, Date reservationDate,
                      String status, double totalPrice, String notes) {
        this.reservationId = reservationId;
        this.guestId = guestId;
        this.roomId = roomId;
        this.checkInDate = checkInDate;
        this.checkOutDate = checkOutDate;
        this.reservationDate = reservationDate;
        this.status = status;
        this.totalPrice = totalPrice;
        this.notes = notes;
        this.services = new ArrayList<>();
    }

    public Reservation(int guestId, int roomId, Date checkInDate, Date checkOutDate,
                      double totalPrice, String notes) {
        this.guestId = guestId;
        this.roomId = roomId;
        this.checkInDate = checkInDate;
        this.checkOutDate = checkOutDate;
        this.reservationDate = new Date();
        this.status = "PENDING";
        this.totalPrice = totalPrice;
        this.notes = notes;
        this.services = new ArrayList<>();
    }

    public int getReservationId() {
        return reservationId;
    }

    public void setReservationId(int reservationId) {
        this.reservationId = reservationId;
    }

    public int getGuestId() {
        return guestId;
    }

    public void setGuestId(int guestId) {
        this.guestId = guestId;
    }

    public int getRoomId() {
        return roomId;
    }

    public void setRoomId(int roomId) {
        this.roomId = roomId;
    }

    public Date getCheckInDate() {
        return checkInDate;
    }

    public void setCheckInDate(Date checkInDate) {
        this.checkInDate = checkInDate;
    }

    public Date getCheckOutDate() {
        return checkOutDate;
    }

    public void setCheckOutDate(Date checkOutDate) {
        this.checkOutDate = checkOutDate;
    }

    public Date getReservationDate() {
        return reservationDate;
    }

    public void setReservationDate(Date reservationDate) {
        this.reservationDate = reservationDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public double getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(double totalPrice) {
        this.totalPrice = totalPrice;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public Guest getGuest() {
        return guest;
    }

    public void setGuest(Guest guest) {
        this.guest = guest;
        if (guest != null) {
            this.guestId = guest.getUserId();
        }
    }

    public Room getRoom() {
        return room;
    }

    public void setRoom(Room room) {
        this.room = room;
        if (room != null) {
            this.roomId = room.getRoomId();
        }
    }

    public ArrayList<Service> getServices() {
        return services;
    }

    public void setServices(ArrayList<Service> services) {
        this.services = services;
    }


    public void addService(Service service) {
        this.services.add(service);
    }

    public boolean removeService(Service service) {
        return this.services.remove(service);
    }

    public int getNumberOfNights() {
        if (checkInDate == null || checkOutDate == null) {
            return 0;
        }
        long diffInMillis = checkOutDate.getTime() - checkInDate.getTime();
        return (int) TimeUnit.DAYS.convert(diffInMillis, TimeUnit.MILLISECONDS);
    }

    public double getTotalServicesCost() {
        double total = 0.0;
        for (Service service : services) {
            total += service.getPrice();
        }
        return total;
    }

    public double getGrandTotal() {
        return totalPrice + getTotalServicesCost();
    }

    public boolean isPending() {
        return "PENDING".equals(status);
    }

    public boolean isConfirmed() {
        return "CONFIRMED".equals(status);
    }

    public boolean isCheckedIn() {
        return "CHECKED_IN".equals(status);
    }

    public boolean isCheckedOut() {
        return "CHECKED_OUT".equals(status);
    }

    public boolean isCancelled() {
        return "CANCELLED".equals(status);
    }

    public void confirm() {
        this.status = "CONFIRMED";
    }

    public void checkIn() {
        this.status = "CHECKED_IN";
        if (room != null) {
            room.markAsOccupied();
        }
    }

    public void checkOut() {
        this.status = "CHECKED_OUT";
        if (room != null) {
            room.markAsAvailable();
        }
    }

    public void cancel() {
        this.status = "CANCELLED";
        if (room != null && room.isOccupied()) {
            room.markAsAvailable();
        }
    }

    public boolean isValid() {
        return guestId > 0 &&
               roomId > 0 &&
               checkInDate != null &&
               checkOutDate != null &&
               checkInDate.before(checkOutDate) &&
               totalPrice >= 0 &&
               status != null && !status.trim().isEmpty();
    }

    @Override
    public String toString() {
        return "Reservation{" +
                "reservationId=" + reservationId +
                ", guestId=" + guestId +
                ", roomId=" + roomId +
                ", checkInDate=" + checkInDate +
                ", checkOutDate=" + checkOutDate +
                ", status='" + status + '\'' +
                ", totalPrice=" + totalPrice +
                ", numberOfNights=" + getNumberOfNights() +
                '}';
    }
}
