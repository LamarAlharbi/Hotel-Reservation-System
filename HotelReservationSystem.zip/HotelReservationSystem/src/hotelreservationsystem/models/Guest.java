package hotelreservationsystem.models;

import java.util.ArrayList;

public class Guest extends User {

    private ArrayList<Reservation> reservations;

    public Guest() {
        super();
        super.setRole("GUEST");
        this.reservations = new ArrayList<>();
    }

    public Guest(int userId, String username, String password, String fullName,
                 String email, String phone, String address) {
        super(userId, username, password, fullName, email, phone, address, "GUEST");
        this.reservations = new ArrayList<>();
    }

    public Guest(String username, String password, String fullName,
                 String email, String phone, String address) {
        super(username, password, fullName, email, phone, address, "GUEST");
        this.reservations = new ArrayList<>();
    }

    public ArrayList<Reservation> getReservations() {
        return reservations;
    }

    public void setReservations(ArrayList<Reservation> reservations) {
        this.reservations = reservations;
    }

    public void addReservation(Reservation reservation) {
        this.reservations.add(reservation);
    }

    public boolean removeReservation(Reservation reservation) {
        return this.reservations.remove(reservation);
    }

    public ArrayList<Reservation> getActiveReservations() {
        ArrayList<Reservation> activeReservations = new ArrayList<>();
        for (Reservation reservation : reservations) {
            String status = reservation.getStatus();
            if (!"CANCELLED".equals(status) && !"CHECKED_OUT".equals(status)) {
                activeReservations.add(reservation);
            }
        }
        return activeReservations;
    }

    public ArrayList<Reservation> getPastReservations() {
        ArrayList<Reservation> pastReservations = new ArrayList<>();
        for (Reservation reservation : reservations) {
            if ("CHECKED_OUT".equals(reservation.getStatus())) {
                pastReservations.add(reservation);
            }
        }
        return pastReservations;
    }

    public int getTotalReservationsCount() {
        return reservations.size();
    }

    @Override
    public String toString() {
        return "Guest{" +
                "userId=" + getUserId() +
                ", username='" + getUsername() + '\'' +
                ", fullName='" + getFullName() + '\'' +
                ", email='" + getEmail() + '\'' +
                ", totalReservations=" + reservations.size() +
                '}';
    }
}
