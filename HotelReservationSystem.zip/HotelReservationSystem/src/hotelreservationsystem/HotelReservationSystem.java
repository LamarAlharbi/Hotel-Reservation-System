package hotelreservationsystem;

import hotelreservationsystem.utils.ViewNavigator;
import javafx.application.Application;
import javafx.stage.Stage;

public class HotelReservationSystem extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception {
        ViewNavigator.setPrimaryStage(primaryStage);
        primaryStage.setTitle("Hotel Reservation System");
        primaryStage.setMinWidth(600);
        primaryStage.setMinHeight(500);
        ViewNavigator.goToLogin();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
